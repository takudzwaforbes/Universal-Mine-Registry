
<?php
session_start();
error_reporting(0);
$cn=mysqli_connect('localhost','root','','mines') or die("Cannot Connect Data");
$_SESSION['success']="True";

$user = $_POST['email'];
       // $password = 123;

        $password = $_POST['password'];

        //include 'config.php';

        $sql = "SELECT * FROM users WHERE email='$user' AND password='$password'  ";
       
        
         $result = mysqli_query($cn,$sql);
         $aaaaa=mysqli_num_rows($result);
         if (mysqli_num_rows($result) > 0) {
       

        $data=mysqli_fetch_array($result);
        $user_role=$data['role'];

        $_SESSION['user_role']=$user_role;
         $_SESSION['user_name']=$user;

        ?>
       
  

 

<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "dashboard";
            }            
            document.write("<h1><center>Login Success.</center></h1>");
            setTimeout('Redirect()', 100);
         //-->
      </script>



        <?php 

    }else{
$_SESSION['success']="Fail";
        /*
        echo "VAR".$aaaaa."<br>";
        echo "username==".$user;
    echo "<br>";
    echo "password==".$password;
    */
    ?>
<script type = "text/javascript">
         <!--
            function Redirect2() {
               window.location = "index";
            }            
            document.write("<h1><center>Login Failed.</center></h1>");
            setTimeout('Redirect2()', 100);
         //-->
      </script>




    <?php
    }

    ?>

























    <?php
    /*
    echo $user;
    echo "<br>";
    echo "HHHH".$password;
    */


?>