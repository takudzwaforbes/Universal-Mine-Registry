<?php
session_start();
$cn=mysqli_connect('localhost','root','','mines') or die("Cannot Connect Data");

$phonenumber=$_POST['phone'];

$firstname=$_POST['firstname'];

$lastname=$_POST['lastname'];

$region=$_POST['region'];

$password=$_POST['password'];

$email=$_POST['email_address'];

$client_number="C".date('Y').rand(0,1000);

$fullname=$firstname." ".$lastname;

$sql_data=mysqli_query($cn,"INSERT INTO `users` (`id`, `email`, `fullname`, `region`, `phonenumber`, `client_id`, `status`, `password`) VALUES ('', '$email', '$fullname', '$region', '$phonenumber', '$client_number', 'valid','$password');");
if($sql_data){
$_SESSION['success']="True";
echo "SUCCESS";
?>
<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "register";
            }            
            document.write("<h1><center> Success.</center></h1>");
            setTimeout('Redirect()', 1000);
         //-->
      </script>


<?php
}else{
	$_SESSION['success']="Fail";
	echo "FAILED";

}

?>