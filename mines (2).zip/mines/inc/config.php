<?php 
	$con = mysqli_connect('localhost','root','','simpleave');
	if (!$con) {
		echo "Database Not Connected";
	}
	$cr7=mysqli_connect('127.0.0.1','root','','simpleave') or die("Cannot  connect SERVER");
	$cn=mysqli_connect('127.0.0.1','root','','stock_take') or die("CANNOT REACH SERVER");
	$cn2=mysqli_connect('127.0.0.1','root','','simpleave') or die("Connot Connect");

$cn1=mysqli_connect('127.0.0.1','root','','testing') or die("CANNOT REACH SERVER");
 ?>