-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2023 at 12:35 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mines`
--

-- --------------------------------------------------------

--
-- Table structure for table `claims`
--

CREATE TABLE `claims` (
  `id` int(11) NOT NULL,
  `onwer` varchar(250) NOT NULL,
  `client_id` varchar(250) NOT NULL,
  `longitude` varchar(250) NOT NULL,
  `latitude` varchar(250) NOT NULL,
  `name_reef` varchar(250) NOT NULL,
  `epo_boundries` varchar(250) NOT NULL,
  `claim_status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `claims`
--

INSERT INTO `claims` (`id`, `onwer`, `client_id`, `longitude`, `latitude`, `name_reef`, `epo_boundries`, `claim_status`) VALUES
(1, 'HOMWE', 'C23456', '44444', '-4555', 'ABC', 'SS', 'available'),
(2, 'FARAI MWASHITA', '10', '12345', '-12345', 'MOUNT', '12345', 'Available'),
(3, 'FARAI MWASHITA', '10', '12345', '-12345', 'MOUNT', '12345', 'Available'),
(4, 'Unknown', '10', '12345', '-12345', 'MOUNT', '12345', 'Current'),
(5, 'MUSAPATIKA', 'P1000', '12345', '-12345', 'MOUNT', '12345', 'Forfeited'),
(6, 'Unknown', 'Unknown', '444444', '444444', 'GWERU', '12345', 'Current'),
(7, 'Unknown', 'Unknown', '262626', '262626', 'MASVINGO', '12345', 'Forfeited'),
(8, 'Unknown', 'Unknown', '889999', '-366999', 'AAAA', '12345', 'Current'),
(9, 'Deregistered', 'Deregistered', '99999', '36666', 'jjjj', '12345', 'Forfeited'),
(10, 'Unknown', 'Unknown', '20', '-20', 'ABCD', '12345', 'Current'),
(11, 'Unknown', 'Unknown', '88', '-88', 'WWW', '12345', 'Forfeited'),
(12, 'Unknown', 'Unknown', '77', '-77', 'SSS', '12345', 'Forfeited'),
(13, 'Unknown', 'Unknown', '999', '-999', 'KWEKWE KWEKWE9', '12345', 'Forfeited'),
(14, 'FRANCIS KAMBARAMIN', 'C2023427', '-17.8537956223', '31.0371650604', 'nyamajura', '12345', 'Current');

-- --------------------------------------------------------

--
-- Table structure for table `output`
--

CREATE TABLE `output` (
  `id` int(11) NOT NULL,
  `client_id` varchar(250) NOT NULL,
  `narration` varchar(250) NOT NULL,
  `revenue` varchar(250) NOT NULL,
  `expense` varchar(250) NOT NULL,
  `date_created` varchar(250) NOT NULL DEFAULT '0',
  `transaction_date` varchar(250) NOT NULL DEFAULT 'NA',
  `profit_loss` varchar(250) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `output`
--

INSERT INTO `output` (`id`, `client_id`, `narration`, `revenue`, `expense`, `date_created`, `transaction_date`, `profit_loss`) VALUES
(1, 'P2310', 'ABC', '10', '2', '12-10-23', '12-10-23', '0'),
(2, 'p2310', 'ABC', '5000', '800', '2023-04-08', '2023-04-08', '0'),
(3, 'p23100', 'ABC', '200000', '1000', '2023-04-08', '2023-04-08', '199000'),
(4, 'P23100', 'ABC', '8000', '1000', '2023-04-09', '2023-04-09', '7000'),
(5, 'P23100', 'ABC', '50000', '3000', '2023-04-09', '2023-04-09', '47000');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `client_id` varchar(250) NOT NULL,
  `holder` varchar(250) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `amount_minus` varchar(250) NOT NULL DEFAULT '0',
  `date_created` varchar(250) NOT NULL,
  `narration` varchar(250) NOT NULL DEFAULT 'NA'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `client_id`, `holder`, `amount`, `amount_minus`, `date_created`, `narration`) VALUES
(1, '47888', 'TAPIWA', '30', '0', '30-03-23', 'NA'),
(2, '10', '10', '95', '0', '2023-04-08', 'NA'),
(3, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(4, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(5, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(6, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(7, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(8, '100', '100', '0', '10', '2023-04-08', 'Inspection Fees  '),
(9, 'C2023977', 'C2023977', '0', '10', '2023-04-08', 'Inspection Fees  '),
(10, 'C2023977', 'C2023977', '30', '0', '2023-04-08', 'NA'),
(11, 'P2310', 'P2310', '', '0', '2023-04-08', 'NA'),
(12, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(13, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(14, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(15, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(16, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(17, '100', '100', '0', '10', '2023-04-19', '  Licence Fee'),
(18, 'C2023977', 'C2023977', '0', '10', '2023-04-19', '  Licence Fee'),
(19, 'C2023427', 'C2023427', '100', '0', '2023-06-04', 'NA');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `fullname` varchar(250) NOT NULL,
  `region` varchar(250) NOT NULL,
  `phonenumber` varchar(250) NOT NULL,
  `client_id` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'pending',
  `username` varchar(250) NOT NULL DEFAULT 'user',
  `password` varchar(250) NOT NULL DEFAULT '12345',
  `role` varchar(250) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `fullname`, `region`, `phonenumber`, `client_id`, `status`, `username`, `password`, `role`) VALUES
(1, 'geniuskudzaihomwe@gmail.com', 'Genius HOMWE', 'Midlands', '0779850816', '100', 'pending', 'user', '12345', 'admin'),
(2, 'Alvin@gmail.com', 'Alvin Mwaurayeni', 'Mashonaland', '0772123123', '100', 'pending', 'user', '12345', 'user'),
(5, 'Alvin@gmail.com', 'Ronald mawaka', 'Midlands', '0779850816', '100', 'pending', 'user', '12345', 'user'),
(6, 'mike@gmail.com', 'Ronald Tarisai mawaka', 'Harare', '0779850815', '100', 'pending', 'user', '12345', 'user'),
(7, 'justice@gmail.com', 'Justice Homwe', 'Harare', '0779850816', 'C2023977', 'pending', 'user', '12345', 'user'),
(8, 'franco@gmail.com', 'FRANCIS KAMBARAMI', 'Midlands', '0778789789', 'C2023427', 'valid', 'user', '12345', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `claims`
--
ALTER TABLE `claims`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `output`
--
ALTER TABLE `output`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `claims`
--
ALTER TABLE `claims`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `output`
--
ALTER TABLE `output`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
