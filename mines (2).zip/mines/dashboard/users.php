<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

if(isset($_SESSION['identifier']) ){
//Grant Access

}else{
  //Do not Grant Access
   header('location:logoff');
}
//check  role incase attack might want to store session



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Library</title>
  <link  rel="icon" href="logo_large.png">

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">


<script type="text/javascript"> 
    function ExcelReport() 
  {
    var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';

    tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
    tab_text = tab_text + '<x:Name>Software Sheet</x:Name>';
    tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

    tab_text = tab_text + "<table border='1px'>";
    tab_text = tab_text + $('#adminTable').html();
    tab_text = tab_text + "</table></body></html>";

    var data_type = 'data:application/vnd.ms-excel';

    $('#export').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
    $('#export').attr('download', 'Midlands CRM Report.xls');
  }
</script>



</head>

<body id="page-top" style="font-family:Times New Roman", Times, serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top"><!--<img src="logo_large.png" >------>

    <a class="navbar-brand mr-1" href="reports"> MSU Hub</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="hidden" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <!--<button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>-->
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/Login_pages/login">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item active">
        <a class="nav-link" href="reports">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span style="color:#FFFFFF">Sub Menus</span>        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Menu:</h6>
          <a class="dropdown-item" href="#">Pending Projects</a>
		  <a class="dropdown-item" href="/final/dashboard/add_fault">Accepted Projects</a>
          <a class="dropdown-item" href="/final/dashboard/escalate">Rejected Projects</a>
          <a class="dropdown-item" href="/final/dashboard/tables">Statistics</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Administrator:</h6>
          <a class="dropdown-item" href="/simba/forgot_password">Add Users?</a>
          <a class="dropdown-item" href="#">Coordinators</a>        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts">
          <i class="fas fa-fw fa-chart-area"></i>
          <span style="color:#FFFFFF">Charts</span></a>
        </li>
      <li class="nav-item">
        <a class="nav-link" href="tables">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Tables</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="../../innovator/login">
          <i class="fa fa-sign-out" aria-hidden="true"></i>
          <span style="color:#FFFFFF">LogOut</span></a>
        </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Midlands State University CRM</a>          </li>
          <li class="breadcrumb-item active"  > <i class="fa fa-users" aria-hidden="true"></i>   Manage Users


         </li>  <!-- The Modal -->

<!--
        <!-- Area Chart Example-
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-chart-area"></i>
            Area Chart Example</div>
          <div class="card-body">
            <canvas id="myAreaChart" width="100%" height="30"></canvas>
          </div>
          <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
-->
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
          
 <p data-toggle="modal" data-target="#myModal">
 <i class="fa fa-plus" aria-hidden="true"></i> New User
</p>


<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><i class="fa fa-plus" aria-hidden="true"></i>New User</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

<form action="" method="post">
      <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">Firstname</label>
  <div class="col-sm-9 col-md-9"><input type="text" class="form-control base_keydown" name="firstname" id="firstname" required /></div>
  </div>

  <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">Surname</label>
  <div class="col-sm-9 col-md-9"><input type="text" class="form-control base_keydown" name="surname" id="surname" required /></div>
  </div>

  <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">Email </label>
  <div class="col-sm-9 col-md-9"><input type="email" class="form-control base_keydown" name="email" id="email" required /></div>
  </div>

<div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">Role</label>
  <div class="col-sm-9 col-md-9"><select class="form-control base_keydown" name="role" id="role" required><option value="">Select Role</option><option value="Admin">Administrator</option><option value="Coordinator">Coordinator</option></select></div>
  </div>

  <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">  </label>
  <div class="col-sm-9 col-md-9">
    <button type="submit" class="btn btn-success" name="btn_staff_account">Submit</button>
     <button type="submit" class="btn btn-warning" data-dismiss="modal">Cancel</button>
  </div>
  </div>
</form>

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        
      </div>

    </div>
  </div>
</div>
<?php
error_reporting(0);
//if isset button
//receive data
$hub_member=array('firstname'=>mysqli_real_escape_string($cn,$_POST['firstname']),'surname'=>mysqli_real_escape_string($cn,$_POST['surname']),'email'=>mysqli_real_escape_string($cn,$_POST['email']),'role'=>mysqli_real_escape_string($cn,$_POST['role']) );
if(ctype_alpha($hub_member['firstname']) and ctype_alpha($hub_member['surname'])){
   if(filter_var($hub_member['email'], FILTER_VALIDATE_EMAIL)){//VALIDATE EMAIL
     
        


                 //create unique project  id
                  $maximum_id=mysqli_query($cn,"SELECT max(id) FROM hub_applicants ");
                  $row_id=mysqli_fetch_array($maximum_id);
                  //create new project id
                  $new_project_id=(1 + $row_id[0]);

                  $finalproject_id="STAFF".$new_project_id;
                  //Add member
   $sql = "INSERT INTO `hub_db`.`hub_applicants` (`id`, `project_id`, `title`, `surname`, `firstname`, `gender`, `date_of_birth`, `nationality`, `national_id`, `email`, `how_you_know`) VALUES (NULL, '$finalproject_id', 'SIR OR MADAM', '".$hub_member['surname']."', '".$hub_member['firstname']."', 'UNDEFINED', NOW(), 'Zw', '$new_project_id', '".$hub_member['email']."', 'News Advertisment')";
                 
                 $insert_data=$cn->query($sql);

                 //insert into login
                  $insert_login=$cn->query("INSERT INTO hub_login (id,email,password,role,date_created) VALUES (NULL,'".$hub_member['email']."','0000','".$hub_member['role']."',NOW()) ");
                   if($insert_data==true){
                   //if success add coordinator to list
                    $fullname=$hub_member['surname']." ".$hub_member['firstname'];

                    if($hub_member['role']=='Coordinator'){
                      //only if he is coordinator
                    $duties=0;
                     $coordinator_add=$cn->query(" INSERT INTO coordinator_duties (id,email,coordinator,number_) VALUES (NULL,'".$hub_member['email']."','$fullname','$duties' ) ");
                         echo "Success Default password is 0000";
                    }else{
                      //Remain silent
                    }
                    
                   
                   }else{
                    echo "Failed".$finalproject_id;
                   }



   }else{
    //not validate email

   }
}else{
  echo "Incorrect format";
}


?>

   <a href="#" id="export" onClick="ExcelReport();" class="btn btn-success btn-block" style="margin-bottom: 20px; margin-top: 20px;"><span class="glyphicon glyphicon-export"></span> Export Report to Excel</a>

             <?php

           if(isset($_SESSION['approved_project'])){
                 echo $_SESSION['approved_project'];
           }




            ?></div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="adminTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Fullname</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Project</th>
                    <th>Date</th>
                     <th>Action</th>
                     <th>Action</th>
                     <th>Action</th>
                     <th>View</th>
                  </tr>
                </thead>
               <tbody>
                  <?php
                    $sql = "SELECT * FROM submitted_papers AS sp JOIN hub_applicants AS ha ON sp.email=ha.email ";
                    $query = $cn->query($sql);
                    while($row = $query->fetch_assoc()){
                      ?>
                        <tr>
                          <td><?php echo $row['surname']." ".$row['firstname']; ?></td>
                          <td><?php echo ucfirst($row['gender']); ?></td>
                          <td><?php echo ucfirst($row['email']); ?></td>
                          <td><?php echo $row['project_title']; ?></td>
                           <td><?php echo ucfirst($row['datee']); ?></td>
                            <td>
                          <a href='set.status?projectid=<?php echo $row['project_id']; ?>'>Approve</a>
                          </td>
                           <td>
                          <a href='set.hold?projectid=<?php echo $row['project_id']; ?>'>Hold</a>
                          </td>
                           <td>
                          <a href='set.reject?projectid=<?php echo $row['project_id']; ?>'>Reject</a>
                          </td>
                          <td>
                          <a href='Pdf/pdf.view?id=<?php echo $row['project_id']; ?>'   target='_blank'>PDF</a>
                          </td>
                        </tr>
                      <?php
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"><!--Updated yesterday at 11:59 PM--></div>
        </div>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Midlands State University Incubation Hub </span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Button to Open the Modal --
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Open modal
  </button>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          Modal body..
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>
<?php
unset($_SESSION['approved_project']);


?>
  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>
</body>
</html>
