<?php
$cn=mysqli_connect('127.0.0.1','root','','attendance') or die("Died");

//clean Table
$table=mysqli_query($cn,"TRUNCATE TABLE attendance_tb");
//
//$table2=mysqli_query($cn,"TRUNCATE TABLE cattle_type");

$table3=mysqli_query($cn,"TRUNCATE TABLE `employees_access_tb` ");

$table4=mysqli_query($cn,"TRUNCATE TABLE log ");

$table5=mysqli_query($cn,"TRUNCATE TABLE `monthy_report` ");

$table6=mysqli_query($cn,"TRUNCATE TABLE `register_sheet` ");

$table7=mysqli_query($cn,"TRUNCATE TABLE quantity ");

$table8=mysqli_query($cn,"TRUNCATE TABLE `sales` ");

$table121=mysqli_query($cn,"TRUNCATE TABLE logs");

$table9=mysqli_query($cn,"TRUNCATE TABLE `leave_tb` ");

$table10=mysqli_query($cn,"TRUNCATE TABLE `users` ");//`employee_in`

$table22=mysqli_query($cn,"TRUNCATE TABLE `employee_in` ");

$table23=mysqli_query($cn,"TRUNCATE TABLE `employee_out` ");//`current_hours_statistics` 

$table29=mysqli_query($cn,"TRUNCATE TABLE `current_hours_statistics` ");

$table39=mysqli_query($cn,"TRUNCATE TABLE   `attendance_tb`  ");//`attendance_out`
$table390=mysqli_query($cn,"TRUNCATE TABLE   `attendance_in`  ");
$table39y=mysqli_query($cn,"TRUNCATE TABLE   `attendance_out`  ");

$table11=mysqli_query($cn,"INSERT INTO `attendance`.`users` (`id`, `ec_number`, `firstname`, `lastname`, `username`, `password`, `email`, `role`, `date_enrolled`, `computer_data`) VALUES (NULL, '190000', 'Genius', 'Homwe', 'GeniusHomwe', '#homwe', 'geniuskudzahomwe@gmail.com', 'admin', '2019-10-06', 'data about data'); ");

header('location:a_users');
?>