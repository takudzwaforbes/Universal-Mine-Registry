<?php
require('fpdf.php');
$con = mysqli_connect("127.0.0.1","root","","hub_db");
$project_id=$_GET['id'];
$com =mysqli_query($con,"SELECT * FROM hub_applicants  WHERE project_id='$project_id'  ");//Join failed--OIN hub_applicants AS ha ON sp.email=ha.email  
$row =mysqli_fetch_assoc($com);

//Now forced to rewrite query
$command=mysqli_query($con,"SELECT project_title FROM  submitted_papers WHERE email='".$row['email']."' ");
$data=mysqli_fetch_assoc($command);

//Now forced to rewrite query
$cmd=mysqli_query($con,"SELECT status FROM  project_status WHERE project__number='".$project_id."' ");
$state=mysqli_fetch_assoc($cmd);

class PDF extends FPDF
{
     function Header()
      {
      $this->SetFont('Arial','B',15);
      $this->cell(12);
      $this->Image('logo.png',10,10,10);
      $this->cell(100,10,'Client List',0,1);
      $this->Ln(5);
        $this->SetFillColor(180,180,255);
      $pdf->SetFont('Arial','B',11);
      $pdf->SetDrawColor(5050,100);
      $this->cell(40,5,'Agent name',1,0);
      $this->cell(40,5,'FirstNmae',1,0);
      $this->cell(40,5,'LastName',1,0);
      $this->cell(40,5,'Phonenumber',1,0);

      }
}
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',21);
$pdf->SetDrawColor(50,50,100);

$pdf->SetTextColor( 50, 50, 50 );

$pdf->cell(100,8,' Midlands State University Incubation Hub ',0,0);
$pdf->cell(20,5,'',0,0);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);

$pdf->SetFont('Arial','B',12);
$pdf->SetDrawColor(50,50,100);

$pdf->cell(40,5,'PROJECT TITLE........',0,0);
$pdf->cell(60,5,'',0,0);
$pdf->cell(100,5,$data['project_title'],0,0);

$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);

$pdf->SetFont('Arial','B',9);
$pdf->SetDrawColor(50,50,100);
$pdf->cell(40,8,'PERSONAL DETAILS',0,1);

$pdf->cell(80,6,'FULLNAME.....',1,0);
$pdf->cell(100,6,$row['firstname']."  ".$row['surname'],1,1);
//$pdf->cell(60,5,,1,1);//one at end means newline



$pdf->cell(80,6,'SEX.....',1,0);
$pdf->cell(100,6,$row['gender'],1,1);

$pdf->cell(80,6,'NATIONAL ID.....',1,0);
$pdf->cell(100,6,$row['national_id'],1,1);


$pdf->cell(80,6,'',0,1);

//Another section
$pdf->cell(40,8,'CONTACT DETAILS',0,1);

$pdf->cell(80,6,'EMAIL.....',1,0);
$pdf->cell(100,6,$row['email'],1,1);
//one at end means newline

$pdf->cell(80,6,'SEX.....',1,0);
$pdf->cell(100,6,$row['gender'],1,1);

$pdf->cell(80,6,'PHONENUMBER.....',1,0);
$pdf->cell(100,6,'N/A',1,1);



$pdf->cell(80,5,'',0,1);
//Another section
$pdf->cell(40,8,'PROJECT DETAILS',0,1);

$pdf->cell(80,6,'PROJECT STATUS.....',1,0);
$pdf->cell(100,6,$state['status'],1,1);
//one at end means newline

$pdf->cell(80,6,'PROJECT ID.....',1,0);
$pdf->cell(100,6,$row['project_id'],1,1);

$pdf->cell(80,6,'PROJECT COORDINATOR.....',1,0);
$pdf->cell(100,6,'N/A',1,1);








$pdf->cell(50,15,'Midlands State University Incubation Hub',0,1);


/*while($row =mysqli_fetch_assoc($com))
        {
             $pdf->cell(20,5,$row ['points'],1,0);
             $pdf->cell(30,5,$row['intake'],1,0);
             $pdf->cell(60,5,$row['programme'],1,0);
             $pdf->cell(50,5,$row['firstname'],1,0);
              $pdf->cell(20,5,$row['sex'],1,1);
        
        }*/
$pdf->Output();
?>