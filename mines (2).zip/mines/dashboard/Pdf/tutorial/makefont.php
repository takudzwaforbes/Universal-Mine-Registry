<?php
//Generation of font definition file for tutorial 7
require('../font/makefont/makefont.php');

MakeFont('calligra.ttf','calligra.afm');
?>
