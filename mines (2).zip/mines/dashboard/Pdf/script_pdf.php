<?php
require('fpdf.php');
$con = mysqli_connect("127.0.0.1","root","","hub_db");
$product_id=$_GET['id'];
$com =mysqli_query($con,"SELECT * FROM submitted_papers AS sp JOIN hub_applicants AS ha ON sp.email=ha.email ");
$row =mysqli_fetch_assoc($com);




class PDF extends FPDF
{
     function Header()
      {
	  $this->SetFont('Arial','B',15);
	  $this->cell(12);
	  $this->Image('logo.png',10,10,10);
	  $this->cell(100,10,'Client List',0,1);
	  $this->Ln(5);
	    $this->SetFillColor(180,180,255);
	  $pdf->SetFont('Arial','B',11);
      $pdf->SetDrawColor(5050,100);
	  $this->cell(40,5,'Agent name',1,0);
	  $this->cell(40,5,'FirstNmae',1,0);
	  $this->cell(40,5,'LastName',1,0);
	  $this->cell(40,5,'Phonenumber',1,0);

      }
}
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',18);
$pdf->SetDrawColor(50,50,100);

$pdf->cell(80,5,' CONCEPT PAPER ',0,0);
$pdf->cell(20,5,'',0,0);
$pdf->cell(80,5,'2018 INTAKE',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->SetFont('Arial','B',9);
$pdf->SetDrawColor(50,50,100);

$pdf->cell(40,5,'PROGRAMME........',0,0);
$pdf->cell(5,5,'',0,0);
$pdf->cell(80,5,$row['project_title'],0,0);
$pdf->cell(10,5,'POINTS',0,0);
$pdf->cell(30,5,'',0,0);
$pdf->cell(10,5,$product_id,0,1);
$pdf->cell(40,5,'TYPE OF ENTRY.....',0,0);
$pdf->cell(20,5,'',0,0);
$pdf->cell(50,5,'',0,0);
$pdf->cell(60,5,'Con',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(40,5,'PERSONAL DETAILS',0,1);
$pdf->cell(80,5,'FULLNAME.....',1,0);
$pdf->cell(40,5,$row['firstname'],1,0);
$pdf->cell(60,5,$row['surname'],1,1);
$pdf->cell(60,5,'MARITAL STATUS.....',1,0);
$pdf->cell(20,5,'Single',1,0);
$pdf->cell(60,5,'SEX.....',1,0);
$pdf->cell(40,5,$row['gender'],1,1);
$pdf->cell(50,5,'NATIONAL ID...',1,0);
$pdf->cell(30,5,$row['national_id'],1,0);
$pdf->cell(60,5,'PASSPORT...',1,0);
$pdf->cell(40,5,'None',1,1);
$pdf->cell(80,5,'NATIONALITY.....',1,0);
$pdf->cell(100,5,$row['nationality'],1,1);
$pdf->cell(80,5,'COUNTRY OF PERMANENT RESIDENCE ...',1,0);
$pdf->cell(100,5,'Zim',1,1);
$pdf->cell(50,5,'DATE OF BIRTH...',1,0);
$pdf->cell(30,5,$row['date_of_birth'],1,0);
$pdf->cell(60,5,'PLACE OF BIRTH...',1,0);
$pdf->cell(40,5,$row['date_of_birth'],1,1);
$pdf->cell(80,5,'DISABILITIES IF ANY (Specify)...',1,0);
$pdf->cell(100,5,'disability',1,1);
$pdf->cell(80,5,'DISABILITY CODE...',1,0);
$pdf->cell(100,5,'05',1,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(40,5,'CONTACT DETAILS',0,1);
$pdf->cell(80,5,'ADDRESS: ...',1,0);
$pdf->cell(100,5,'address',1,1);
$pdf->cell(50,5,'TELEPHONE NUMBERS',1,1);
$pdf->cell(50,5,'HOME...',1,0);
$pdf->cell(30,5,'',1,0);
$pdf->cell(60,5,'CONTACT NUMBER...',1,0);
$pdf->cell(40,5,'phone_number',1,1);
$pdf->cell(80,5,'E-MAIL...',1,0);
$pdf->cell(100,5,$row['email'],1,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(40,5,'PROSPECTIVE SPONSORS',0,1);
$pdf->cell(80,5,'SPONSORS: ...',1,0);
$pdf->cell(100,5,'sponser',1,1);
$pdf->cell(80,5,'Are you a university staff dependant...',1,0);
$pdf->cell(100,5,'uni_dep',1,1);
$pdf->cell(80,5,'Are you a university staff member...',1,0);
$pdf->cell(100,5,'staff',1,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(40,5,'ACCEPTANCE CODE',0,0);
$pdf->cell(20,5,'',0,0);
$pdf->cell(40,5,'.............',0,0);
$pdf->cell(10,5,'RECEIPT NO',0,0);
$pdf->cell(40,5,'',0,0);
$pdf->cell(10,5,'.......................',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(90,5,'PROGRAMMES OF STUDY FOR WHICH YOU ARE APPLYING',0,1);
$pdf->cell(80,5,'1-DEGREE PROGRAMME ...',1,0);
$pdf->cell(100,5,$row['objective1'],1,1);
$pdf->cell(80,5,'2-DEGREE PROGRAMME ...',1,0);
$pdf->cell(100,5,$row['objective1'],1,1);
$pdf->cell(80,5,'2-DEGREE PROGRAMME ...',1,0);
$pdf->cell(100,5,$row['objective1'],1,1);

$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'TYPE OF ENTRY ...',1,0);
$pdf->cell(100,5,'type_of_entry',1,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(90,5,'SCHOOL EXAMINATIONS FOR WHICH RESULTS ARE KNOWN',0,1);
$pdf->cell(90,5,' �O� level subjects including mathematics and english ',0,1);
$pdf->cell(30,5,'DATE',1,0);
$pdf->cell(60,5,'EXAMINATION BOARD',1,0);
$pdf->cell(50,5,'SUBJECT',1,0);
$pdf->cell(40,5,'RESULT/GRADE',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject',1,0);
$pdf->cell(40,5,'grade',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject2',1,0);
$pdf->cell(40,5,'grade2',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject3',1,0);
$pdf->cell(40,5,'grade3',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject4',1,0);
$pdf->cell(40,5,'grade4',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject5',1,0);
$pdf->cell(40,5,'grade5',1,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);
$pdf->cell(80,5,'',0,1);

$pdf->cell(90,5,' �A� LEVEL SUBJECTS  ',0,1);
$pdf->cell(30,5,'DATE',1,0);
$pdf->cell(60,5,'EXAMINATION BOARD',1,0);
$pdf->cell(50,5,'SUBJECT',1,0);
$pdf->cell(40,5,'RESULT/GRADE',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject',1,0);
$pdf->cell(40,5,'grade',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject2',1,0);
$pdf->cell(40,5,'grade2',1,1);
$pdf->cell(30,5,'date1',1,0);
$pdf->cell(60,5,'board',1,0);
$pdf->cell(50,5,'subject3',1,0);
$pdf->cell(40,5,'grade3',1,1);
$pdf->cell(30,5,'',1,0);
$pdf->cell(60,5,'',1,0);
$pdf->cell(50,5,'',1,0);
$pdf->cell(40,5,'',1,1);
$pdf->cell(50,10,'',0,1);
$pdf->cell(80,5,'UNIVERSITIES/COLLEGES ATTENDED....',1,0);
$pdf->cell(100,5,'uni_att',1,1);
$pdf->cell(80,5,'WORK EXPERIENCE / EMPLOYMENT....',1,0);
$pdf->cell(100,5,'work_ex',1,1);
$pdf->cell(80,5,' NAME OF REFERENCE....',1,0);
$pdf->cell(100,5,'ref',1,1);
$pdf->cell(80,5,' ADDRESS OF REFERENCE....',1,0);
$pdf->cell(100,5,'ll',1,1);
$pdf->cell(80,5,' DATE SIGNED....',1,0);
$pdf->cell(100,5,'23 DEC 2017',1,1);
$pdf->cell(50,15,'Powered by Manicaland State University of Applied Sciences IT Department',0,1);


/*while($row =mysqli_fetch_assoc($com))
		{
		     $pdf->cell(20,5,$row ['points'],1,0);
			 $pdf->cell(30,5,$row['intake'],1,0);
			 $pdf->cell(60,5,$row['programme'],1,0);
			 $pdf->cell(50,5,$row['firstname'],1,0);
			  $pdf->cell(20,5,$row['sex'],1,1);
		
		}*/
$pdf->Output();
?>