<?php


class DB {
	
	public $db_name = 'mines';
	public $db_user = 'root';
	public $db_pass = '';
	public $db_host = '127.0.0.1';
	
	//i am using contructor so as to make function called automatically Genius.Homwe
	public function __construct()  {
	
		$connect_db = new mysqli( $this->db_host, $this->db_user, $this->db_pass, $this->db_name );
		
		if ( mysqli_connect_errno() ) {
			printf("Connection failed: %s\
", mysqli_connect_error());
			exit();
		}
		return true;
		
	}

}
//$varr=new DB;

//echo "Good";
//$cn=mysqli_connect('127.0.0.1','root','','hub_db');
$cr7=mysqli_connect('127.12.47.50','root','','mines') or die("Cannot  connect SERVER");

$cn=mysqli_connect('127.12.47.50','root','','mines') or die("Cannot  connect SERVER");






function success_sms($parameter,$message){

    print"<br>
<div class='alert alert-".$parameter."'>
  <strong>".$message."</strong> 
</div>";
	
}


                 function send_mail($table,$message,$receiver,$subject,$attachment,$status){
                 global $cn;
                 $send_email=mysqli_query($cn,"INSERT INTO $table (message,receiver,subject,attachment,id,status)VALUES('$message','$receiver','$subject','$attachment',NULL,'$status')");
                      	
                      }


//function insert into login table
function add_innovator($cn,$table,$email,$password,$role){
  $add_innovator=$cn->query("INSERT INTO $table (id,email,password,role,date_created) VALUES (NULL,'$email','$password','innovator',NOW()) ");

  if($add_innovator==true){
     //if successful
    header('location:login');
  }else{
    //error
  }
}
     function create_session($cn,$email){
     	$select_details=mysqli_query($cn,"SELECT CONCAT (title,surname,firstname) AS fullname FROM hub_applicants WHERE email='$email' ");
        $extract_details=mysqli_fetch_assoc($select_details);
        $_SESSION['Fullname']=$extract_details['fullname'];
        return $_SESSION['Fullname'];
     }

     //session 2
     function create_session_mail($cn,$email){
      $select_details=mysqli_query($cn,"SELECT email FROM hub_applicants WHERE email='$email' ");
        $extract_details=mysqli_fetch_assoc($select_details);
        $_SESSION['eemail']=$extract_details['email'];
        return $_SESSION['eemail'];
     }
   
  


//function login
function login_verification($cn,$email,$password){
   $verify=mysqli_query($cn,"SELECT * FROM hub_login WHERE email='$email' AND password='$password' ");
   $extract_role=mysqli_fetch_assoc($verify);
   $rows=mysqli_num_rows($verify);
        //create session
   

   if($rows > 0){
       if($extract_role['role']=='innovator'){
         //Login successfull
          header('location:in.asp');
          }elseif($extract_role['role']=='Coordinator'){
          //Coordinator
           header('location:../admin');
         }
    
   }else{
   	//Login unsuccessfull
      print"<br>
<div class='alert alert-danger'>
  <strong><center>Incorrect Credentials</center></strong> 
</div>";
   }
}
function prevent_session_theft($identifier){
  global $cn;
  $prevent=mysqli_query($cn,"SELECT role FROM hub_login WHERE email='$identifier' ");
  $fetch_role=mysqli_fetch_assoc($prevent);
  return $fetch_role['role'];
}
?>