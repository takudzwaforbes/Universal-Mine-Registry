<?php
	$start=mysqli_connect("localhost","root","","final");
	$retrieve=mysqli_query($start,"SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Control Panel</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body id="page-top" style="font-family:Arial, Helvetica, sans-serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="reports.php" style="font-family:Arial, Helvetica, sans-serif; font-style:italic">PowerTel Communications (Pvt) Ltd<img src="/final/Login_pages/assets/img/logo.png" height="45px" width="100px" style="margin-left:4px"></a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">

    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/administrator/Login_pages/login.php">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item">
        <a class="nav-link" href="reports.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Menu:</h6>
		  <a class="dropdown-item" href="/final/dashboard/reports.php">View Reports</a>
          <a class="dropdown-item" href="/final/dashboard/add_fault.php">Add New Fault</a>
          <a class="dropdown-item" href="/final/dashboard/escalate.php">Escalate Fault</a>
          <a class="dropdown-item" href="/final/dashboard/tables.php">View Pending Faults</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <a class="dropdown-item" href="#">Forgot Password?</a>
          <a class="dropdown-item" href="#">List of All technicians</a>        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>      </li>
      <li class="nav-item active">
        <a class="nav-link" href="tables.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>      </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <!-- Breadcrumbs1-->
        <ol class="breadcrumb" style="text-align:center; background-color:#00CC33;color:#FFFFFF">
          <li class="">    </li>
          <li class="breadcrumb-item active"><p style="color:#FFFFFF; margin:0px">Add New User</p></li>
        </ol>
		<form method="post" action="/final/dashboard/admin.php">
<?php
	$conect=mysqli_connect("localhost","root","","final");
	if(isset($_POST["add_user"]))
	{
		$firstname=mysqli_real_escape_string($conect,$_POST["fname"]);
		$lastname=mysqli_real_escape_string($conect,$_POST["lname"]);
		$email=mysqli_real_escape_string($conect,$_POST["email"]);
		$pass1=mysqli_real_escape_string($conect,$_POST["password1"]);
		$pass2=mysqli_real_escape_string($conect,$_POST["password2"]);
		$department=$_POST["department"];
		if($pass1!=$pass2)
		{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> Passwords do not match
				</div>";
		}
		else if(strlen($pass1)<6)
		{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> Password should be at least characters long
				</div>";
		}
		else
		{
			$check=mysqli_query($conect,"SELECT * FROM users WHERE username='$firstname' AND lastname='$lastname'");
			$counter=mysqli_num_rows($check);
			if($counter!=0)
			{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> A user with the Firstname and Last Name already exist
				</div>";
			}
			else
			{
				$final_query="INSERT INTO users (username,lastname,password,email,department) VALUES ('$firstname','$lastname','$pass2','$email','$department')";
				if(!mysqli_query($conect,$final_query))
				{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> System Error occured!
				</div>";
				}
				else
				{
				echo"<div class='alert alert-success'>
  				<strong></strong> User successfully added.
				</div>";
				}
			}
		}
	}
?>
		<table align="center">
		<tr>
			<td>
			<input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" value="<?php echo isset($_POST["fname"])?$_POST["fname"]:""; ?>" style="margin-bottom:3px; width:300px" required>	
			</td>
		</tr>
		<tr>
			<td>
			<input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" value="<?php echo isset($_POST["lname"])?$_POST["lname"]:""; ?>" style="margin-bottom:3px; width:300px" required>	
			</td>
		</tr>
		<tr>
			<td>
			<input type="text" class="form-control" name="email" id="email" placeholder="Email Address" value="<?php echo isset($_POST["email"])?$_POST["email"]:""; ?>" style="margin-bottom:3px; width:300px" required>	
			</td>
		</tr>
		<tr>
			<td>
			<input type="password" class="form-control" name="password1" id="password1" placeholder="Enter Password" style="margin-bottom:3px; width:300px" required>	
			</td>
		</tr>
		<tr>
			<td>
			<input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" style="margin-bottom:3px; width:300px" required>	
			</td>
		</tr>
		<tr>
			<td>
				<select name="department" class="form-control" style="margin-bottom:3px; width:300px">
				<option value="">--Select Department--</option>
				<option value="Technician">Technician</option>
				<option value="client services Agent">Client Services Agent</option>
				<option value="sales staff">Sales Staff</option>
				<option value="Manager">Manager</option>
				</select>
			</td>
		</tr>
	<tr>
		<td><button type="submit" class="btn btn-primary" name="add_user" id="add_user" style="margin:1.5px; background-color:#006699; float:right">Add User</button></td>
	</tr>
		</table>
		</form>
        <!-- Breadcrumbs-->
        <ol class="breadcrumb" style="text-align:center; background-color:#FF3333;color:#FFFFFF">
          <li class="">           </li>
          <li class="breadcrumb-item active"><p style="color:#FFFFFF; margin:0px">Remove User</p></li>
        </ol>
		<form method="post" action="/final/dashboard/admin.php">
<?php
	$con2=mysqli_connect("localhost","root","","final");
	if(isset($_POST["delete"]))
	{
		$email=mysqli_real_escape_string($con2,$_POST["email"]);
		$name=mysqli_real_escape_string($con2,$_POST["dusername"]);
		$password=mysqli_real_escape_string($con2,$_POST["dpassword"]);
		$check123=mysqli_query($con2,"SELECT * FROM users WHERE username='$name' AND email='$email'");
		$results=mysqli_num_rows($check123);
		if($results==0)
		{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> User not found!
				</div>";	
		}
		else
		{
			$delete="DELETE FROM users WHERE username='$name' AND email='$email'";
			if(!mysqli_query($con2,$delete))
			{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> Request Failed
				</div>";	
			}
			else
			{
				echo"<div class='alert alert-success'>
  				<strong></strong> User successfully removed.
				</div>";
			}
		}
	}
?>
		<table align="center" style="text-align:center">
	<tr>
		<td>
		<input type="text" class="form-control" name="email" id="email" placeholder="Enter Email Address" value="<?php echo isset($_POST["email"])?$_POST["email"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
	<tr>
		<td>
		<input type="text" class="form-control" name="dusername" id="dusername" placeholder="Enter the username" value="<?php echo isset($_POST["dusername"])?$_POST["dusername"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
	<tr>
		<td>
		<input type="password" class="form-control" name="dpassword" id="dpassword" placeholder="Enter Password" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
	<tr>
		<td><button type="submit" class="btn btn-primary" name="delete" id="delete" style="margin:1.5px; background-color:#006699; float:right">Delete User</button></td>
	</tr>
		</table>
		</form>
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header" style="font-family:"Courier New", Courier, monospace">
            <i class="fas fa-table"></i>
            List of the Users registered in the system</div>
          <div class="card-body">
            <div class="table-responsive">
			
			<form method="post" action="/final/dashboard/escalate.php">

              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email Address</th>
                    <th>Department</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>

                  </tr>
                </tfoot>
                <tbody>
               <?php
			
				while($rows=mysqli_fetch_assoc($retrieve))
				{
			echo"<tr>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$rows['username']."</td>";
		echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$rows['lastname']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$rows['email']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$rows['department']."</td>";
					echo"</tr>";
				}
			?>
                </tbody>
              </table>
			  </form>
            </div>
          </div>
          <div class="card-footer small text-muted"><!--Updated yesterday at 11:59 PM--></div>
        </div>

        <p class="small text-center text-muted my-5">
          <em><!--More table examples coming soon...--></em>        </p>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright � System Developed by Simbarashe Nchenamilo</span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">�</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>
</body>
</html>
