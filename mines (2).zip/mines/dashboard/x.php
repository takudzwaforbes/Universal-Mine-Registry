<?php
//session_start();
//include 'db/db.php';
$cr7=mysqli_connect('127.12.47.50','root','','attendance') or die("Cannot  connect SERVER");
error_reporting(0);
//$ref="ZRP".$generate_reference;
$expire_stamp = date('F d, Y H:i', strtotime("+3 min"));
//echo "<br><hr>";
$now_stamp    = date("Y-m-d H:i");



$query=mysqli_query($cr7,"SELECT CURTIME() AS nguva ");
$fetch_time=mysqli_fetch_array($query);
$Time_limit = date('H:m');
//echo   "<h1>nguva".$fetch_time['nguva']."</h1>";
//echo  "<h1>".$Time_limit."</h1>";
if($fetch_time['nguva'] > '15:20:00'){
    //time dzakwana
//echo   "<h1>Greater than 2100</h1>";
//Select * EC NUMBERS AVAILABLE INSIDE
$select_in_ecz=mysqli_query($cr7,"SELECT ec_number as ec FROM  `employee_in` ");
   while($employees=mysqli_fetch_array($select_in_ecz)){
         //**********************************8*******************************************************
 $id_number=$employees['ec'];

  $password='';
  $activity=2;
  $monday=date('D');
  $session_id=rand(1,100000)."A".TIME()."L".date('d');
  //Check First
  function emp_access($c_id,$id,$pwd,$activity,$session_id){
    //Check activity   1=IN and 2=OUT
    if($activity=='1'){
      $sql_access=mysqli_query($c_id,"SELECT * FROM   `employees_access_tb` WHERE ec_number='$id'  AND ec_number NOT IN (SELECT ec_number FROM  `employee_in` ) ");
       $answer=mysqli_num_rows($sql_access);
       if($sql_access){
         if($answer > 0){
                  $exchange=$c_id->query("INSERT INTO `attendance`.`employee_in` (`id`, `ec_number`, `session_id`) VALUES (NULL, '$id','$session_id');");
         $exchange2=$c_id->query("DELETE FROM `attendance`.`employee_out` WHERE ec_number IN (SELECT ec_number FROM  `employee_in`) ;");
         // $exchange3=$c_id->query("DELETE FROM `attendance`.`employee_in` WHERE session_id NOT IN (SELECT session_id FROM  `attendance_in`) ;");
         }else{
          //Ignore

         }//end answer sql

          }//End sql true


    }else{//IF EMPIS OUT
       $sql_access=mysqli_query($c_id,"SELECT * FROM   `employees_access_tb` WHERE ec_number='$id'  AND ec_number NOT IN (SELECT ec_number FROM  `employee_out` ) ");
       $answer=mysqli_num_rows($sql_access);
        if($sql_access){
              if($answer > 0){
         $exchange=$c_id->query("INSERT INTO `attendance`.`employee_out` (`id`, `ec_number`) VALUES (NULL, '$id');");
        // $exchange2=$c_id->query("DELETE FROM `attendance`.`employee_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
         //Compute statistics
       }else{
        //Ignore

       }//end SQL answer
      }//end sql true




    }    
       return $answer;
  }
  function attendance($id,$activity,$session_id){ //SELECT * FROM lib_access_report WHERE status='Allowed' AND date_time=CURDATE()
  global $cr7;
    $computer_data=array(
      'remote_address'=>$_SERVER['REMOTE_ADDR']
      ,'http_agent'=>$_SERVER['HTTP_USER_AGENT']
      ,'remote_port'=>$_SERVER['REMOTE_PORT']
                                           );  
                                           // echo "DONE-0"; 
    
    if($activity==1){
          //echo "DONE ACTIVITY";
      $time_inn1=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
       $time_inn_copy=$cr7->query("INSERT INTO `attendance`.`attendance_in_copy` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
 
     $time_inn200=$cr7->query("INSERT INTO `attendance`.`attendance_out` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
          $activity_data='IN';
     // $time_inn=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
           }else{
          $activity_data='OUT';
         // echo "DONE ACTIVITY 2";
    // $time_inn=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
     $time_inn2=$cr7->query("INSERT INTO `attendance`.`attendance_out_copy` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
     //NO MORE INSERTION BUT UPDATING
     $php_look_for_session=mysqli_query($cr7,"SELECT ec_number, session_id FROM `employee_in` WHERE ec_number='$id' ");
     $php_fetch_session=mysqli_fetch_array($php_look_for_session);
     $emp_number=$php_fetch_session['ec_number'];
     $emp_session=$php_fetch_session['session_id'];
//Updating===Crucial part
  $run_updates=$cr7->query("UPDATE `attendance`.`attendance_out` SET `time_in`=NOW(), `date_in`=CURDATE() WHERE `ec_number`='$emp_number' AND  `session_id`='$emp_session' ");
  //echo "DONE ACTIVITY=next";


  //Compute hours
  $start_time=mysqli_query($cr7,"SELECT time_in,date_in FROM  `attendance_in` WHERE ec_number='$emp_number'  AND session_id='$emp_session' ");
  $fetch_time_start=mysqli_fetch_array($start_time);
  $emp_in=$fetch_time_start['time_in'];
   $emp_date_in=$fetch_time_start['date_in'];
   $first_parameter=$emp_date_in." ".$emp_in;

   //PARAMETER 2
 $start_time2=mysqli_query($cr7,"SELECT time_in,date_in FROM  `attendance_out` WHERE ec_number='$emp_number'  AND session_id='$emp_session' ");//and date
  $fetch_time_start2=mysqli_fetch_array($start_time2);
  $emp_in2=$fetch_time_start2['time_in'];
   $emp_date_in2=$fetch_time_start2['date_in'];
    $second_parameter=$emp_date_in2." ".$emp_in2;

//**********************************************************************Hour rate
    /* $sql258 = "SELECT * FROM salary_rates WHERE id=1 ";
                    $query = $cr7->query($sql258);
                    $row258 = $query258->fetch_assoc();
                    $current_rate=$row258['basic_rate'];

*/
 //echo "DONE ACTIVITY=next rates<br>";


   //*********************
 $work_rate=mysqli_query($cr7,"SELECT * FROM salary_rates ");
    $rates109=mysqli_fetch_array($work_rate);
    $curr_rate=$rates109['basic_rate'];


   //*********************
             $hour_rate=$curr_rate * 0.25;
             // Declare two dates 
             $start_date = strtotime($first_parameter); 
             $end_date = strtotime($second_parameter); 
            // Get the difference and divide into  
            // total no. seconds 60/60/24 to get  
            // number of days 
           //echo "Difference between two dates: "
             $days_passed1=round(($end_date - $start_date)/60/60,2);//IF I WERE TO UDJUST 
              $days_passed= $days_passed1 * 0.5;
             $salary=$hour_rate*$days_passed;
   //*********************
       //insert into statistics
      $hour_statistics=$cr7->query("INSERT INTO `attendance`.`current_hours_statistics` (`id`, `ec_number`, `hours`, `hour_rate`, `payoff`, `month`, `date_generated`) VALUES (NULL, '$emp_number', '$days_passed', '$hour_rate', '$salary', '".date('M')."', CURDATE())");

$dashboard=$cr7->query("INSERT INTO `attendance`.`register_sheet` (`id`, `ec_number`, `time_in`, `time_off`, `status`, `date`) VALUES (NULL, '$emp_number', '$emp_in', '$emp_in2', 'present', '$emp_date_in2');");


      $exchange2=$cr7->query("DELETE FROM `attendance`.`employee_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
      //hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee

       $exchange2000=$cr7->query("DELETE FROM `attendance`.`attendance_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
     // echo "DONE ACTIVITY=next rates TILL DELETE<br>";
     
          }
    $data=$computer_data['remote_address'].$computer_data['http_agent'].$computer_data['http_port'].date('Y:M:d');
    $sql_att=$cr7->query("INSERT INTO `attendance`.`attendance_tb` (`id`, `ec_number`,`session_id`, `time_in`, `time_out`, `month`, `status`, `branch`, `valid`, `computer_data`) VALUES (NULL, '$id','$session_id', NOW(), '', '".date('M')."', '$activity_data', 'Mutare', 'yes', '".$data."'); ");
    //return mysqli_num_rows($lib_limit);
   // echo "DONE LAST LINE";
  }//END FUNCTION




                        function check_leave($ec){
                          global $cr7;
                          //Select start time
                          $start_time=mysqli_query($cr7,"SELECT ec_number FROM  `leave_tb` WHERE ec_number='$ec'  ");
                          return mysqli_num_rows($start_time);
                          }

  $lib_capacity=40;
           if(check_leave($id_number) < 1){//Leave
  if(emp_access($cr7,$id_number,$password,$activity,$session_id) > 0 ){
      
    //
          //echo "Mr Homwe";
          attendance($id_number,$activity,$session_id);
          //Compute statistics
          //insert record
         if($activity==1){
          
                    }else{
                      // echo "activity 2"; 
                            

                 }
    


  }else{ // echo "PASSWORD WRONG OR DUPLICATE CHECKING IN"; 
                //insert record
    


    }
    //Denied
    
  
}else{   


 //$exchange6=$c_r7->query("DELETE FROM `attendance`.`employee_in` WHERE session_id NOT IN (SELECT session_id FROM  `attendance_in`) ;");
     }//function emp access
                       




$activity4='Manually Logging Emplyee';
      $comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************

header('location:attendance_dashboard#');
                      
 unset($id_number,$password);








   	//***********************************************************************************************
   }
















}else{
echo   "<h1>Less than 2100</h1>";
//ignore remain quit




}






//echo "Right now: " . $now_stamp;
//echo "<br><hr>";
//echo "5 minutes from right now: " . $expire_stamp;
/*
$select_ref=mysqli_query($cn,"SELECT ec_number FROM `automatic_logoff` ");

while($ref=mysqli_fetch_array($select_ref)){
  //One by one
  $sql_data=mysqli_query($cn,"SELECT * FROM `automatic_logoff`   WHERE ec_number= '".$ref['ec_number']."'  ");
  $roda=mysqli_fetch_array($sql_data);

$parameter=$roda['end_time'];//Parameter Sent to JS



$a = new DateTime('07:00');
$b = new DateTime('16:00');
$interval = $a->diff($b);

echo $interval->format("%H");
$hhh=$interval->format("%H");









 //echo "-".$now_stamp."--".$parameter;
//$homwe = $_GET["result"] ;//Result from JS
//echo "<br><hr>";
//echo  $parameter."<br>";
//$notify=$cn->query("INSERT INTO `zrp`.`notifications` (`id`, `reference`) VALUES (NULL, '".$ref['Reference_number']."' );");
 if($now_stamp==$parameter){
 	//echo "<h1>HOMWE HOMWE  DONE</h1>";
 	$notify=$cn->query("INSERT INTO `zrp`.`notifications` (`id`, `reference`) VALUES (NULL, '".$ref['Reference_number']."' );");

 }else{
 	//echo "<h1>HOMWE HOMWE WAITING FAILED</h1>";
 }


}

*/

//Powered by Homwe
?>
<script language="javascript">
setTimeout(function(){
   window.location.reload(1);
},31000);
</script>
