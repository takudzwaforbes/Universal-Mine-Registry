<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

 //Trim emil to remove white spaces
$a=array('ec_number'=>mysqli_real_escape_string($cr7,$_POST['ec_number']),
         'end_date'=>mysqli_real_escape_string($cr7,$_POST['end_date']),
     );
        $current_date=date('Y:m:d');
        $start_date = strtotime($current_date); 
        $end_date = strtotime($a['end_date']); 
        $abc=($end_date-$start_date/60/60/24);

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$checkID=mysqli_query($cr7,"SELECT * FROM users WHERE  ec_number='".$a['ec_number']."' ");
    $count = mysqli_num_rows($checkID);
    
    if($count > 0){
      $force_value=$end_date - $start_date;

     if($force_value > 0){



//Insert
      $activity4='Adding user on Leave->'.$a['ec_number'];
      $comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");


       $add_project=$cr7->query("INSERT INTO `attendance`.`leave_tb` (`id`, `ec_number`, `start_date`, `end_date`, `duration`, `days_left`) VALUES (NULL, '".$a['ec_number']."', CURDATE(), '".$a['end_date']."', '$abc', '$force_value'); ") or mysqli_error();
     
      echo "Project exist";
      //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Leave recorded</center></strong> 
</div>";
     }else{
      //incorrect date
 $_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Invalid Date</center></strong> 
</div>";
     }




      

    }else{
    	//insert record
     $_SESSION['approved_project']="<br>
              <div class='alert alert-danger'>
              <strong><center>EC Number cannot be Found</center></strong> 
              </div>";

 	   
        }
    
    
header('location:leave_days#');


?>