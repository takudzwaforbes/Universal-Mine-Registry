<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$claim_id=mysqli_real_escape_string($cn,$_POST['claim_id']);
$amount=mysqli_real_escape_string($cn,$_POST['amount']);
$service=mysqli_real_escape_string($cn,$_POST['service']);


if(1==1){

	$insert_data=mysqli_query($cn,"INSERT INTO `payments` (`id`, `client_id`, `holder`, `amount`, `date_created`) VALUES (NULL, '$claim_id', '$claim_id', '$amount', CURDATE() ); ");


if($insert_data){
	$_SESSION['approved_project']="True";
/*
	echo "Success".$id;
	echo "<br>";
	echo $claim_holder;
	echo "<br>";
	echo $claim_id;
	echo "<br>";
	echo $longitude;
	echo "<br>";
	echo $name_of_reef."--<br>".$_SESSION['approved_project'];
	*/
	

}else{
	$_SESSION['approved_project']="Failed";
	echo "Failed";
}


}
			
?>
<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "payments";
            }            
            document.write("<h1><center>Redirect.</center></h1>");
            setTimeout('Redirect()', 10);
         //-->
      </script>