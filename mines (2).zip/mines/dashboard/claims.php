<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();



if(isset($_SESSION['identifier']) ){
//Grant Access
 // header('location:attendance_dashboard#');

}else{
  //Do not Grant Access
  // header('location:logoff');
}
//check  role incase attack might want to store session


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  
  <title><?php
    error_reporting();
     //echo $_SESSION['identifier'];
      ?></title>
  <!--<link  rel="icon" href="logo_large.png">-->

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">


<script type="text/javascript"> 
    function ExcelReport() 
  {
    var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';

    tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
    tab_text = tab_text + '<x:Name>Software Sheet</x:Name>';
    tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

    tab_text = tab_text + "<table border='1px'>";
    tab_text = tab_text + $('#adminTable').html();
    tab_text = tab_text + "</table></body></html>";

    var data_type = 'data:application/vnd.ms-excel';

    $('#export').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
    $('#export').attr('download', 'Midlands CRM Report.xls');
  }
</script>



</head>

<body id="page-top" style="font-family:Times New Roman", Times, serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top"><!--<img src="logo_large.png" >------>

    <a class="navbar-brand mr-1" href="reports">Universal Mine Registry</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="hidden" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <!--<button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>-->
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/Login_pages/login">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">







   <!-- Sidebar -->
       <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item active">
        <a class="nav-link" href="reports">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
   


      <li class="nav-item">
        <a class="nav-link" href="output">
          <i class="fas fa-fw fa-chart-area"></i>
          <span style="color:#FFFFFF">Forecast</span></a>
        </li>
      <li class="nav-item">
        <a class="nav-link" href="reports">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Mines</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="claims">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Claims</span></a>
        </li>

<li class="nav-item">
        <a class="nav-link" href="payments">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Payments</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="client_verification">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Verification</span></a>
        </li>

        <li class="nav-item">
        <a class="nav-link" href="change.pwd">
          <i class="fas fa-lock"></i>
          <span style="color:#FFFFFF">Change Password</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="/mines">
          <i class="fa fa-user"></i>
          <span style="color:#FFFFFF">LogOut</span></a>
        </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
<?php
//force change password--$_SESSION['identifier']
/*
function change_default_password($email){
      global $cn;
      $check=mysqli_query($cn,"SELECT * FROM hub_login WHERE email='$email' and password='0000' ");//we do not want them to use default passwords
      $userfound=mysqli_num_rows($check);
       if($userfound > 0){

        header('location:change.pwd');

       }else{
        //remain silent if all is well

       }
    // return $userfound;
}
*/
//change_default_password($_SESSION['identifier']);
?>
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Universal Mine Registry Dashboard</a>          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-comments"></i>                </div>
                <div class="mr-5">

              <?php
              error_reporting(0);
               function extract_project_number($connection,$table){
                $fetch_sql=mysqli_query($connection,"SELECT * FROM $table");
                $count_project=mysqli_num_rows($fetch_sql);

                return $count_project;
               }
               //use method overide
               function extract_project_number_($connection,$table,$condition){
                $fetch_sql=mysqli_query($connection,"SELECT * FROM $table  WHERE 1 ");
                $count_project=mysqli_num_rows($fetch_sql);

                return $count_project;
               }

              ?>

                <?php echo extract_project_number($cn,'users');   ?> All Mines!



              </div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>                </span>              </a>            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-list"></i>                </div>
                <div class="mr-5">   <?php echo extract_project_number_($cn,'project_status','Pending');   ?>Financial forecast!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>                </span>              </a>            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-shopping-cart"></i>                </div>
                <div class="mr-5"><?php echo extract_project_number_($cn,'project_status','Approved');   ?>Payments!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>                </span>              </a>            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-danger o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-life-ring"></i>                </div>
                <div class="mr-5"><?php  echo extract_project_number_($cn,'project_status','Rejected');   ?>Claims</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>                </span>              </a>            </div>
          </div>
        </div>






    <i class="fa fa-tasks" aria-hidden="true"></i><a href='add_claim'><button class="btn btn-warning">Add Mine Claim </button></a>
   <a href="#" id="export" onClick="ExcelReport();" class="btn btn-success btn-block" style="margin-bottom: 20px; margin-top: 20px;"><span class="glyphicon glyphicon-export"></span> Export Report to Excel</a>

            <?php
             //$id=$_GET['projectid'];

           if($_SESSION['approved_project']=='True'){
                // echo $_SESSION['approved_project'];
                 ?>
<div class='alert alert-success'>
  <strong><center><font color='black'>YOU HAVE SUCCESSFULLY EDITED</font></center></strong> 
</div>

          <?php

           }else if($_SESSION['approved_project']=='Failed'){
            ?>
            <div class='alert alert-warning'>
  <strong><center><font color='black'>OPERATION FAILED</font></center></strong> 
</div>

           <?php
           }else if($_SESSION['approved_project']==''){


           }
       
           ?>
 <div class="container-fluid">
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header" style="font-family:"Courier New", Courier, monospace">
            <i class="fas fa-table"></i>
            List of All mine claims</div>
          <div class="card-body">
            <div class="table-responsive">
      
      <form method="post" action="">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                     <th>ID #</th>
                    <th>Holder</th>
                    <th>Client’s P/L Numbers </th>
                    <th>Coodinates</th>
                    <th>Name Reef</th>
                     <th>Claim Status</th>
                     <th>Action</th>
                     <th>Action</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>

                  </tr>
                </tfoot>
                
<tbody>
                  <?php
                    $sql = "SELECT * FROM claims ";
                    $query = $cn->query($sql);
                    while($row = $query->fetch_assoc()){
                      ?>
                        <tr>
                          <td><?php echo $row['id']; ?></td>
                          <td><?php echo $row['onwer']; ?></td>
                          <td><?php echo ucfirst($row['client_id']); ?></td>
                          <td><?php echo $row['longitude']." ".$row['latitude']; ?></td>
                           <td><?php echo ucfirst($row['name_reef']); ?></td>
                            <td>
                        <?php echo $row['claim_status']; ?>
                          </td>
                           <td bgcolor="yellow">
                          <a href='edit_claim?projectid=<?php echo $row['id']; ?>'>Allocate Holder</a>
                          </td>
                          <td bgcolor="red">
                          <a href='process_deregister?id=<?php echo $row['id']; ?>'>Deregister</a>
                          </td>v
                          
                        </tr>
                      <?php
                    }
                  ?>
                


                </tbody>
              </table>
        </form>
            </div>
          </div>
          <div class="card-footer small text-muted"><!--Updated yesterday at 11:59 PM--></div>
        </div>

        <p class="small text-center text-muted my-5">
          <em><!--More table examples coming soon...--></em>        </p>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Ministry of Mines and Mineral Development </span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>

</body>
</html>
<?php

unset($_SESSION['approved_project']);
$_SESSION['approved_project']='';

?>

