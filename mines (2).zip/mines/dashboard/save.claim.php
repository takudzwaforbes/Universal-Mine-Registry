<?php

//echo "Jeremiah";
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$claim_holder=mysqli_real_escape_string($cn,$_POST['claim_holder']);
$claim_id=mysqli_real_escape_string($cn,$_POST['claim_id']);
$longitude=mysqli_real_escape_string($cn,$_POST['longitude']);
$latitude=mysqli_real_escape_string($cn,$_POST['latitude']);
$name_of_reef=mysqli_real_escape_string($cn,$_POST['name_of_reef']);

$status=mysqli_real_escape_string($cn,$_POST['status']);

if(1==1){

	$insert_data=mysqli_query($cn,"INSERT INTO `claims` (`id`, `onwer`, `client_id`, `longitude`, `latitude`, `name_reef`, `epo_boundries`, `claim_status`) VALUES (NULL, '$claim_holder', '$claim_id', '$longitude', '$latitude', '$name_of_reef', '12345', '$status')");


if($insert_data){
	$_SESSION['approved_project']="True";
	echo "Success";
	echo "<br>";
	echo $claim_holder;
	echo "<br>";
	echo $claim_id;
	echo "<br>";
	echo $longitude;
	echo "<br>";
	echo $name_of_reef;

}else{
	echo "Failed";
}


}
			
?>

<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "add_claim";
            }            
            document.write("<h1><center>Redirect.</center></h1>");
            setTimeout('Redirect()', 10);
         //-->
      </script>