<?php
//i want to nreceive data from front end
$number1=$_POST['number1'];
$number2=$_POST['number2'];


//let add too numbers

$result=$number1+$number2;
echo $result;



?>