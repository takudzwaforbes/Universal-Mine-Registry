<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//Get Email
$bond=$_GET['bond'];
 //Trim emil to remove white spaces
 $new_bond=trim($bond);

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}
$activity4='Changing Hour Rate ';
      $comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************
	

    
    if($bond > 0  AND $bond < 500000){
    	 $add_project=$cr7->query("UPDATE `salary_rates` SET basic_rate='$new_bond' WHERE id=1 ");
     
      echo "Project exist";
      //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-info'>
  <strong><center>Hour Rate Configured</center></strong> 
</div>";

    }else{
    	//insert record
    
 	    //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Invalid Input</center></strong> 
</div>";

 
    }
    
header('location:hours');


?>