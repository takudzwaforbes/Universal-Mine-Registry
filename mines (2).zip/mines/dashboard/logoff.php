<?php
session_start();

unset($_SESSION['identifier']);
header('http://127.0.0.1/mines/');//Go back Home
session_start();
unset($_SESSION['identifier']);

header('location:../../');

if(!empty($_SESSION['identifier'])){
  echo (" <br>Not Empty");

}else{
	echo ("<br>Empty");
}


?>