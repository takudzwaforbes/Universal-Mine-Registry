<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

if(isset($_SESSION['identifier']) ){
//Grant Access

}else{
  //Do not Grant Access
   header('location:logoff');
}
//check  role incase attack might want to store session




?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Attendance-Password</title>
  <!--<link  rel="icon" href="logo_large.png">-->

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">


<script type="text/javascript"> 
    function ExcelReport() 
  {
    var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';

    tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
    tab_text = tab_text + '<x:Name>Software Sheet</x:Name>';
    tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

    tab_text = tab_text + "<table border='1px'>";
    tab_text = tab_text + $('#adminTable').html();
    tab_text = tab_text + "</table></body></html>";

    var data_type = 'data:application/vnd.ms-excel';

    $('#export').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
    $('#export').attr('download', 'Pockets Solutions.xls');
  }
</script>



</head>

<body id="page-top" style="font-family:Times New Roman", Times, serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top"><!--<img src="logo_large.png" >------>

    <a class="navbar-brand mr-1" href="reports">Attendance</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="hidden" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <!--<button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>-->
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logoff">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item active">
        <a class="nav-link" href="reports">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
    <!--  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span style="color:#FFFFFF">Sub Menus</span>        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Menu:</h6>
          <a class="dropdown-item" href="#">Pending Projects</a>
      <a class="dropdown-item" href="/final/dashboard/add_fault">Accepted Projects</a>
          <a class="dropdown-item" href="/final/dashboard/escalate">Rejected Projects</a>
          <a class="dropdown-item" href="/final/dashboard/tables">Statistics</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Administrator:</h6>
          <a class="dropdown-item" href="users">Add Users?</a>
          <a class="dropdown-item" href="#">Coordinators</a>        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts">
          <i class="fas fa-fw fa-chart-area"></i>
          <span style="color:#FFFFFF">Charts</span></a>
        </li>-->
      <li class="nav-item">
        <a class="nav-link" href="logs#">
        
          <span style="color:#FFFFFF">Audit Trails</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="emp_pin#">
        
          <span style="color:#FFFFFF">Employee PIN</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="logoff">
          <i class="fa fa-sign-out" aria-hidden="true"></i>
          <span style="color:#FFFFFF">LogOut</span></a>
        </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
<?php
//force change password--$_SESSION['identifier']

function change_default_password($email){
      global $cn;
      $check=mysqli_query($cn,"SELECT * FROM hub_login WHERE email='$email' and password='0000' ");//we do not want them to use default passwords
      $userfound=mysqli_num_rows($check);
       if($userfound > 0){

        //header('location:change.pwd');

       }else{
        //remain silent if all is well

       }
    // return $userfound;
}
//change_default_password($_SESSION['identifier']);
?>

<?php
error_reporting(0);

$messaging='HELLO:  ';
$aa="PUT VALID EMPLOYEE EC# TO RESET PASSWORD";
$password=array('ec'=>$_POST['oldpwd'],'newpwd'=>$_POST['newpwd'],'conpwd'=>$_POST['conpwd']);

$check_pwd=mysqli_query($cr7,"SELECT  * FROM `employees_access_tb` WHERE ec_number='".$password['ec']."'  ");
if(mysqli_num_rows($check_pwd) > 0){
   $messaging='EC # NOT FOUND';
      if (strcmp($password['conpwd'],$password['newpwd'])==0){



           if($password['conpwd'] <= 1000){
              echo "<div class='alert alert-warning'>
  <strong><center>You are recommended to Set a stronger PIN! Try Again</center></strong> 
</div>";
           }else{
            //go forward


         //update password now
         $change_pwd=mysqli_query($cr7,"UPDATE `employees_access_tb` SET password='".$password['newpwd']."' WHERE ec_number='".$password['ec']."' ");
          echo "<div class='alert alert-success'>
  <strong><center>PIN CODE  CHANGED</center></strong> 
</div>";

$activity4='Has Reseted Employee ACCESS PIN'.$password['ec'];
      $comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************

           }//end strong PIN






      }else{
      //password mismatch
       echo "<div class='alert alert-danger'>
  <strong><center>PIN CODE Mismatch</center></strong> 
</div>";
}

}else{
  //incorrect password
 
 echo "<div class='alert alert-danger'>
  <strong><center>$messaging<em>".strtoupper($_SESSION['identifier']). "</em>  ".$aa ." </center></strong> 
</div>";

}//end num rows





?>

       <!-- Breadcrumbs-
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <center><a href="#">Change Password Form</a> </center>
                     </li>
          <li class="breadcrumb-item active"></li>
        </ol>-->


<center><p data-toggle="modal" data-target="#myModal"><font color='red'>To Reset Employee Access Password click here</font></p></center>


<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">New Password</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

<form action="" method="post">
      <div class="form-group row">
  <label class="col-sm-5 col-md-5 lbl">EC #</label>
  <div class="col-sm-7 col-md-7"><input type="text" class="form-control base_keydown" name="oldpwd" id="oldpwd" required /></div>
  </div>

  <div class="form-group row">
  <label class="col-sm-5 col-md-5 lbl">New password</label>
  <div class="col-sm-7 col-md-7"><input type="password" class="form-control base_keydown" name="newpwd" id="newpwd" required /></div>
  </div>

  <div class="form-group row">
  <label class="col-sm-5 col-md-5 lbl">Confirm password</label>
  <div class="col-sm-7 col-md-7"><input type="password" class="form-control base_keydown" name="conpwd" id="conpwd" required /></div>
  </div>


  <div class="form-group row">
  <label class="col-sm-5 col-md-5 lbl">  </label>
  <div class="col-sm-7 col-md-7">
    <button type="submit" class="btn btn-success" name="btn_change_pwd">Submit</button>
     <button type="submit" class="btn btn-warning" data-dismiss="modal">Cancel</button>
  </div>
  </div>
</form>

      </div>

      <!-- Modal footer -
      <div class="modal-footer">
        
      </div>-->

    </div>
  </div>
</div>






      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Pockets Solutions </span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Button to Open the Modal --
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Open modal
  </button>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          Modal body..
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>
<?php
unset($_SESSION['approved_project']);


?>
  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logoff">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>
</body>
</html>
