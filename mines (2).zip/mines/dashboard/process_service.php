<?php

//echo "Jeremiah";
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$barcode=mysqli_real_escape_string($cr7,$_POST['barcode']);
$reference=mysqli_real_escape_string($cr7,$_POST['reference']);
$hours=mysqli_real_escape_string($cr7,$_POST['hours']);
$reasons=mysqli_real_escape_string($cr7,$_POST['reason']);
/*function check_id($id){
	global $cr7;
	$check=mysqli_query($cr7,"SELECT id_number FROM access_entry WHERE id_number='$id' ");
	return mysqli_num_rows($check);
}
function book_existance($barcode){
	global $cr7;
	$books=mysqli_query($cr7,"SELECT barcode FROM books WHERE barcode='$barcode' ");
	return mysqli_num_rows($books);
}
function return_service($barcode){
	global $cr7;
	$service=mysqli_query($cr7,"SELECT status FROM books WHERE barcode='$barcode' ");
	$fetch=mysqli_fetch_assoc($service);
	return $fetch['status'];
}
function book_limit($id_number){
	global $cr7;
	$limit=mysqli_query($cr7,"SELECT id_number FROM issue_return  WHERE id_number='$id_number' ");
	return mysqli_num_rows($limit);
}*/



if(0== 0){
	//Procced
	if(1==1){
          //Procced book exist
		if(2==2){//AND return_service($barcode)=='Available'
		   if($hours > 0 AND $hours < 12){
			//Insert
			$activity4='Changing Hours of a user->'.$barcode."Reason-> ".$reasons;
			$comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************
    $work_rate=mysqli_query($cr7,"SELECT * FROM salary_rates ");
    $rates109=mysqli_fetch_array($work_rate);
    $curr_rate=$rates109['basic_rate'];
             $payoff=$curr_rate * $hours;


             //Update table
       $update=$cr7->query("UPDATE  `current_hours_statistics` SET  `hours` =  '$hours', `payoff` =  '$payoff', `hour_rate` =  '$curr_rate'   WHERE  `id` ='$reference' ;");
               //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Hours Saved</center></strong> 
</div>";

		    }else{
			//echo "Reached Book limit Return one or All";
			$_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Invalid Hours</center></strong> 
</div>";
		     }//3==3


		}else
		{//$service_type=='Return' AND return_service($barcode)=='Borrowed'
		

		}//2==2

	}else{
		//Book not available in system
		echo "1==1";
	}//1==1

}else{
	//cannot procced not a student
	echo "0=0";
}//0==0


header('location:hours#');


?>