<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

 //Trim emil to remove white spaces
$a=array('barcode'=>mysqli_real_escape_string($cr7,$_POST['barcode']),
      'book_value'=>mysqli_real_escape_string($cr7,$_POST['book_value']),
       'auther'=>mysqli_real_escape_string($cr7,$_POST['auther']),
       'title'=>mysqli_real_escape_string($cr7,$_POST['title']),
       'publisher'=>mysqli_real_escape_string($cr7,$_POST['publisher']),
       'year'=>mysqli_real_escape_string($cr7,$_POST['year']),
       'category'=>mysqli_real_escape_string($cr7,$_POST['category'])
     );

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$checkID=mysqli_query($cn,"SELECT * FROM project_status WHERE  project__number='$new_email' ");
    $count = mysqli_num_rows($checkID);
    
    if(1==1){

    	 $add_project=$cr7->query("INSERT INTO `library`.`books` (`id`, `auther`, `title`, `category`, `condition`, `status`, `barcode`, `value`, `date_`) VALUES (NULL, '".$a['auther']."', '".$a['title']."', '".$a['category']."', '".$a['auther']."', 'Available', '".$a['barcode']."', '".$a['book_value']."', NOW()); ") or mysqli_error();
     
      echo "Project exist";
      //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-info'>
  <strong><center>Book Submitted</center></strong> 
</div>";

    }else{
    	//insert record
     $_SESSION['approved_project']="<br>
              <div class='alert alert-info'>
              <strong><center>Barcode already Exist</center></strong> 
              </div>";

 	   
        }
    
    
header('location:books#');


?>