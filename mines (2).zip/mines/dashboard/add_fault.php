<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Add New Fault</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body id="page-top" style="font-family:Arial, Helvetica, sans-serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="reports.php" style="font-family:Arial, Helvetica, sans-serif; font-style:italic">PowerTel Communications (Pvt) Ltd<img src="/final/Login_pages/assets/img/logo.png" height="45px" width="100px" style="margin-left:4px"></a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="text" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/Login_pages/login.php">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item">
        <a class="nav-link" href="reports.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Menu:</h6>
		  <a class="dropdown-item" href="/final/dashboard/reports.php">View Reports</a>
          <a class="dropdown-item" href="/final/dashboard/add_fault.php">Add New Fault</a>
          <a class="dropdown-item" href="/final/dashboard/escalate.php">Escalate Fault</a>
          <a class="dropdown-item" href="/final/dashboard/tables.php">View Pending Faults</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <a class="dropdown-item" href="#">Forgot Password?</a>
          <a class="dropdown-item" href="#">List of All technicians</a>        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>      </li>
      <li class="nav-item">
        <a class="nav-link" href="tables.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>      </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">


        <!-- Page Content -->
				<div id="cover_map" style="width:22%; margin:auto; float:left">
			<p style="text-align:center; text-decoration:underline">Network Coverage Map</p>
			<img src="/final/Login_pages/assets/img/CoverageMap.jpg" width="530px" height="">			</div>
			<div id="body" style="width:65.75%; margin:auto; padding-top:1px; padding-bottom:10px; padding-left:80px; float:right">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb" style="text-align:center; background-color:;color:#FFFFFF">
          <li class="">           </li>
          <li class="breadcrumb-item active">Add New Fault</li>
        </ol>
				<form method="post" action="/final/dashboard/add_fault.php" style="background-color:;border-radius: 15px; width:80%; margin:auto; padding-top:px">
<?php
	$con=mysqli_connect("localhost","root","","final");
	if(isset($_POST["add"]))
	{
		$company=mysqli_real_escape_string($con,$_POST["cname"]);
		$address=mysqli_real_escape_string($con,$_POST["address"]);
		$number=mysqli_real_escape_string($con,$_POST["cnum"]);
		$email=mysqli_real_escape_string($con,$_POST["email"]);
		$city=$_POST["city"];
		$issue=$_POST["issue"];
		$status=$_POST["status"];
		$details=mysqli_real_escape_string($con,$_POST["fdetails"]);
		$technician=mysqli_real_escape_string($con,$_POST["technician"]);
		$manager=mysqli_real_escape_string($con,$_POST["agname"]);
		$aemail=mysqli_real_escape_string($con,$_POST["aemail"]);
		$switch=$_POST["switch"];
		$port=mysqli_real_escape_string($con,$_POST["port"]);
		$date=date("Y-m-d H:i:s");
		$fault_number=$id=Rand(0,2000);
		$query="INSERT INTO faults (company_name,physical_address,contact_number,email,city,issue,status,other_details,techncian,account_manager,manager_email,date,fault_number,switch,port) VALUES ('$company','$address','$number','$email','$city','$issue','$status','$details','$technician','$manager','$aemail','$date','$fault_number','$switch','$port')";
		if(!mysqli_query($con,$query))
		{
				echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> Error occured whilst adding fault please try again
				</div>";
		}
		
		else
		{
				echo"<div class='alert alert-success'>
  				<strong></strong>Fault has been successfully added, the fault number is <a href='#'>$fault_number</a><br\>
				Click here to view <a href='/final/dashboard/tables.php'>pending faults</a>
				</div>";
		}
	}	
?>
	<table align="center">
		<tr>
		 <td>
			<input type="text" class="form-control" name="cname" id="cname" placeholder="Company Name" style="margin-bottom:3px; width:300px"value="<?php echo isset($_POST["cname"])?$_POST["cname"]:""; ?>" required>			</td>
		</tr>
				<tr>
					<td>
					<textarea class="form-control" rows="3" id="address" name="address" placeholder="Physical Address"style="margin-bottom:3px; width:300px" value="<?php echo isset($_POST["address"])?$_POST["address"]:""; ?>" required></textarea>					</td>
				</tr>
	<tr>
		<td>
		<input type="text" class="form-control" name="cnum" id="cnum" placeholder="Contact Number"value="<?php echo isset($_POST["cnum"])?$_POST["cnum"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
	<tr>
		<td>
		<input type="text" class="form-control" name="email" id="email" placeholder="Email Address" value="<?php echo isset($_POST["email"])?$_POST["email"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
							<tr>
								<td>
									<select name="city" class="form-control" style="margin-bottom:3px; width:300px">
									<option value="">--Select City--</option>
									<option value="Harare">Harare</option>
									<option value="Bulawayo">Bulawayo</option>
									<option value="Gweru">Gweru</option>
									<option value="Mutare">Mutare</option>
									</select>								</td>
							</tr>
						<tr>
							<td>
							<select name="issue" class="form-control" style="margin-bottom:3px; width:300px">
							<option value="">--Issue--</option>
							<option value="utp">Utp</option>
							<option value="cable">Cable fault</option>
							<option value="Config">Configuration issues</option>
							<option value="other">other</option>
							</select>						</td>
				</tr>
						<tr>
							<td>
							<select name="switch" class="form-control" style="margin-bottom:3px; width:300px">
							<option value="">--Select Terminal Switch--</option>
							<option value="bindura">Bindura switch</option>
							<option value="harare">Harare CBD</option>
							<option value="ruwa">Ruwa switch</option>
							<option value="marondera">Marondera</option>
							<option value="norton">Norton</option>
							<option value="Gweru sw1">Gweru Switch 1</option>
							<option value="Gweru sw2">Gweru Switch 2 </option>
							<option value="Hwange">Hwange</option>
							<option value="Glen Eagles">Glen Eagles</option>
							<option value="Kadoma">Kadoma</option>
							<option value="Kwekwe">Kwekwe</option>
							<option value="Joina City">Joina city</option>
							<option value="Mpumalanga">Mpumalanga</option>
							<option value="Bulawayo sw1">Bulawayo Switch 1</option>
							<option value="Bulawayo sw2">Bulawayo Switch 2</option>
							<option value="Southerton">Southerton </option>
							<option value="Angwa city">Angwa city</option>
							</select>						</td>
				</tr>
	<tr>
		<td>
		<input type="text" class="form-control" name="port" id="port" placeholder="Port Number" style="margin-bottom:3px; width:300px"value="<?php echo isset($_POST["port"])?$_POST["port"]:""; ?>" required>		</td>
	</tr>
						<tr>
							<td>
							<select name="status" class="form-control" style="margin-bottom:3px; width:300px">
							<option value="Pending">Pending</option>
							<option value="Cleared">Cleared</option>
							<option value="New Link">New Lik</option>
							</select>						</td>
				</tr>

		<tr>
			<td>
		<small id="emailHelp" class="form-text text-muted" style="margin:4px; color:#FF0000">*Please enter other fault details here.</small>			</td>
		</tr>
		<tr>
			<td>
			<textarea class="form-control" rows="3" id="fdetails" name="fdetails" placeholder="Other?"value="<?php echo isset($_POST["fdetails"])?$_POST["fdetails"]:""; ?>" style="margin-bottom:3px; width:300px"required></textarea>			</td>
		</tr>
		<tr>
	<td><small id="emailHelp" class="form-text text-muted" style="margin:4px; color:#FF0000">*Assign Fault to a Technician.</small></td>
		</tr>
						<tr>
							<td>
							<select name="technician" class="form-control" style="margin-bottom:3px; width:300px">
							<option value="">--Select Technician--</option>
							<option value="Mafunga">Mafunga</option>
							<option value="Chihava">Chihava</option>
							<option value="Chakachadza">Chakachadza</option>
							<option value="Martin">Martin</option>
							</select>						</td>
				</tr>		
	<tr>
		<td>
		<input type="text" class="form-control" name="agname" id="agname" placeholder="Account Manager"value="<?php echo isset($_POST["agname"])?$_POST["agname"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
	<tr>
		<td>
		<input type="text" class="form-control" name="aemail" id="aemail" placeholder="Email Address"value="<?php echo isset($_POST["aemail"])?$_POST["aemail"]:""; ?>" style="margin-bottom:3px; width:300px" required>		</td>
	</tr>
<tr>
	<td>
	<small id="emailHelp" class="form-text text-muted" style="margin:4px; color:#FF0000">*Fault Number and date are generated by the system.</small>	</td>
</tr>
	<tr>
		<td><button type="submit" class="btn btn-primary" name="add" id="add" style="margin:1.5px; background-color:#006699">Add Fault</button></td>
	</tr>
		</table>
				</form>
			</div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>
</body>
</html>
