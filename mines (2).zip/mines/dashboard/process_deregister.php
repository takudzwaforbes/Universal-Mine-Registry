<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$id=mysqli_real_escape_string($cn,$_GET['id']);
/*
$claim_holder=mysqli_real_escape_string($cn,$_POST['holder']);
$claim_id=mysqli_real_escape_string($cn,$_POST['claim_id']);
$longitude=mysqli_real_escape_string($cn,$_POST['longitude']);
$latitude=mysqli_real_escape_string($cn,$_POST['latitude']);
$name_of_reef=mysqli_real_escape_string($cn,$_POST['name_of_reef']);

$status=mysqli_real_escape_string($cn,$_POST['status']);
*/

if(1==1){

	$insert_data=mysqli_query($cn,"UPDATE `claims` SET  onwer='Deregistered' , client_id='Deregistered' WHERE id='$id' ");


if($insert_data){
	$_SESSION['approved_project']="True";
/*
	echo "Success".$id;
	echo "<br>";
	echo $claim_holder;
	echo "<br>";
	echo $claim_id;
	echo "<br>";
	echo $longitude;
	echo "<br>";
	echo $name_of_reef."--<br>".$_SESSION['approved_project'];
	*/
	

}else{
	$_SESSION['approved_project']="Failed";
	echo "Failed";
}


}
			
?>
<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "claims";
            }            
            document.write("<h1><center>Redirect.</center></h1>");
            setTimeout('Redirect()', 10);
         //-->
      </script>