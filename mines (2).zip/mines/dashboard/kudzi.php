<html>
<head>
	</head>
	<body>
		


ADDITION<br>
<form action="back_end"  method="post">
<label>first number</label><br>
<input type="text" name="number1">
<label>Second number</label><br>
<input type="text" name="number2"><br>
<input type="submit" name="">
</form>
	</body>


</html>