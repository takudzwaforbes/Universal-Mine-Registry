<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//Get Email
$id=$_GET['id'];
 
    
    if(1==2){
    	 

    }else{
    	//insert record
     $add_project=$cn->query("DELETE FROM users WHERE id='$id' ");
       if($add_project==true){
 	    //success sms

 	    //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Success Deleted</center></strong> 
</div>";;

   echo "Success";
        }else{
         //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Process Failed Try Again!</center></strong> 
</div>";;

        }
    }
    
header('location:reports');


?>