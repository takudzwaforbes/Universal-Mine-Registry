<?php

session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//Get Email
$email=$_GET['projectid'];
 //Trim emil to remove white spaces
 $new_email=trim($email);

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$checkID=mysqli_query($cn,"SELECT * FROM project_status WHERE  project__number='$new_email' ");
    $count = mysqli_num_rows($checkID);
    
    if($count > 0){
    	 $add_project=$cn->query("UPDATE project_status SET status='Rejected' WHERE project__number='$new_email' ");
     
    	
    	//create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-info'>
  <strong><center>Project Status Updated (Rejected)</center></strong> 
</div>";

    }else{
    	//insert record
     $add_project=$cn->query("INSERT INTO project_status (project_id,project__number,status,datee) VALUES (NULL,'$new_email','Rejected',NOW()) ");
       if($add_project==true){
 	    //success sms

 	    //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Success Project Rejected</center></strong> 
</div>";;

   echo "Success";
        }else{
         //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Process Failed</center></strong> 
</div>";;

        }
    }
    
header('location:reports');


?>