<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();



if(isset($_SESSION['identifier']) ){
//Grant Access
 // header('location:attendance_dashboard#');

}else{
  //Do not Grant Access
  // header('location:logoff');
}
//check  role incase attack might want to store session


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  
  <title><?php
    error_reporting();
     //echo $_SESSION['identifier'];
      ?></title>
  <!--<link  rel="icon" href="logo_large.png">-->

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">


<script type="text/javascript"> 
    function ExcelReport() 
  {
    var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';

    tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
    tab_text = tab_text + '<x:Name>Software Sheet</x:Name>';
    tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

    tab_text = tab_text + "<table border='1px'>";
    tab_text = tab_text + $('#adminTable').html();
    tab_text = tab_text + "</table></body></html>";

    var data_type = 'data:application/vnd.ms-excel';

    $('#export').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
    $('#export').attr('download', 'Midlands CRM Report.xls');
  }
</script>



</head>

<body id="page-top" style="font-family:Times New Roman", Times, serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top"><!--<img src="logo_large.png" >------>

    <a class="navbar-brand mr-1" href="reports">Universal Mine Registry</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="hidden" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <!--<button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>-->
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/Login_pages/login">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

   

 <!-- Sidebar -->
       <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item active">
        <a class="nav-link" href="reports">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
   <li class="nav-item">
        <a class="nav-link" href="output">
          <i class="fas fa-fw fa-chart-area"></i>
          <span style="color:#FFFFFF">Forecast</span></a>
        </li>

<?php
error_reporting(0);
if($_SESSION['user_role']=='admin'){
?>
      
      
        <li class="nav-item">
        <a class="nav-link" href="claims">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Claims</span></a>
        </li>

<li class="nav-item">
        <a class="nav-link" href="payments">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Payments</span></a>
        </li>
        <?php
      }

        ?>

        <li class="nav-item">
        <a class="nav-link" href="client_verification">
          <i class="fas fa-fw fa-table"></i>
          <span style="color:#FFFFFF">Verification</span></a>
        </li>

        
        <li class="nav-item">
        <a class="nav-link" href="/mines">
          <i class="fa fa-user"></i>
          <span style="color:#FFFFFF">LogOut</span></a>
        </li>
    </ul>







    <div id="content-wrapper">

      <div class="container-fluid">

 

 

             <?php
             error_reporting(0);
            // $id=$_GET['projectid'];

           if($_SESSION['approved_project']=='True'){
                
                 ?>
<div class='alert alert-success'>
  <strong><center><font color='black'>YOU HAVE SUCCESSFULLY PAID</font></center></strong> 
</div>

          <?php

           }else if($_SESSION['approved_project']=='Failed'){
            ?>
            <div class='alert alert-warning'>
  <strong><center><font color='black'>OPERATION FAILED</font></center></strong> 
</div>

           <?php
           }else if($_SESSION['approved_project']==''){


           }
           $data=mysqli_query($cn,"SELECT * FROM claims ");
           $data_array=mysqli_fetch_array($data);
           ?>
 <div class="container-fluid">
<center><h2>Claim Forecasting</h2></center>


   <form action="" method="post">

     

  <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl"><font color='black'>Client’s P/L Numbers </font></label>
  <div class="col-sm-9 col-md-9">
   <input type="text" class="form-control base_keydown" name="pp" id="pp" required  />
  </div>
  </div>

  <div class="form-group row">
  <label class="col-sm-3 col-md-3 lbl">  </label>
  <div class="col-sm-9 col-md-9">
    <button type="submit" class="btn btn-success" name="btn_staff_account">Submit</button>
    
  </div>
  </div>
</form>
 <button  class="btn btn-warning" onclick="print_one()" >Print</button>
<script type="text/javascript">
  function print_one(){
    window.print();
  }

</script>

      <!--<button class="btn btn-warning" >Z-READING</button><br><br> -->
      <script type="text/javascript">
        function zreading(){
          window.location.href='z_reading.php';
        }
      </script>
     
             
<?php
 $p=$_POST['pp'];
?>
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                     <th>ID #</th>
                    
                    <th>P/L Numbers </th>
                    <th>Revenue</th>
                     <th>Expense</th>
                      <th>Profit/loss</th>
                    <th>Date created</th>
                    <th>Transaction Date</th>
                     
                     
                  </tr>
                </thead>
                <tfoot>
                  <tr>

                  </tr>
                </tfoot>
                
<tbody>
                  <?php
                 
                    $sql = "SELECT * FROM output WHERE client_id='$p'   ";
                    $query = $cn->query($sql);
                    while($row = $query->fetch_assoc()){
                      ?>
                        <tr>
                          <td><?php echo $row['id']; ?></td>
                          <td><?php echo $row['client_id']; ?></td>
                   
                          <td bgcolor="green">$<?php echo $row['revenue']; ?></td>
                          <td bgcolor="red">$<?php echo $row['expense']; ?></td>
                            <td bgcolor="pink">$<?php echo $row['profit_loss']; ?></td>
                           <td><?php echo ucfirst($row['date_created']); ?></td>
                            <td><?php echo ucfirst($row['transaction_date']); ?></td>
                           
                          
                          
                        </tr>
                      <?php
                    }
                  ?>
                


                </tbody>
              </table>









            </div>
          </div>
          <div class="card-footer small text-muted"><!--Updated yesterday at 11:59 PM--></div>
        </div>

        <p class="small text-center text-muted my-5">
          <em><!--More table examples coming soon...--></em>        </p>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Ministry of Mines and Mineral Development </span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>

</body>
</html>
<?php

unset($_SESSION['approved_project']);
$_SESSION['approved_project']='';

?>
