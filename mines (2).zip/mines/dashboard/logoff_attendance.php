<?php

session_start();
include 'db/db.php';
error_reporting(0);
//receive information from innovator
if(isset($_POST['btn_start'])){
	//if(isset($id_number)){
   //header('location:start');	078348357	

	//}
	
//When button is set
	//$innovator=array(0=>$_POST['title'],1=>$_POST['surname'],2=>$_POST['firstnames'],3=>$_POST['gender'],4=>$_POST['dob'],5=>$_POST['country'],6=>$_POST['idnum'],7=>$_POST['email'],8=>$_POST['knowid']);
//Library system

  //UPDATE DUE DATES  MAKE IT A ROUTINE
    function updates_due_dates($connection){
    	//Format table
    	$erase=$connection->query("TRUNCATE TABLE  `due_dates`");
    	//current date minus issied date
    	     $EveryID=mysqli_query($connection,"SELECT id_number,barcode FROM `issue_return` ");
    	     While ($codes=mysqli_fetch_array($EveryID)){
    	     	$id_number=$codes['id_number'];
    	     	$barcode=$codes['barcode'];

                   //fetch start date
             $php_find_start_date=mysqli_query($connection,"SELECT date_issued FROM `issue_return` WHERE barcode='$barcode'  ");
             $php_fetch_date=mysqli_fetch_assoc($php_find_start_date);
             $date_approved=$php_fetch_date['date_issued'];//Issued
             $current_date=date('Y-m-d');
             // Declare two dates 
             $start_date = strtotime($date_approved); 
             $end_date = strtotime($current_date); 
            // Get the difference and divide into  
            // total no. seconds 60/60/24 to get  
            // number of days 
           //echo "Difference between two dates: "
             $days_passed=($end_date - $start_date)/60/60/24; 
             //INSERT INTO TABLE
             $update_table=$connection->query("INSERT INTO `library`.`due_dates` (`id`, `id_number`, `barcode`, `days`) VALUES (NULL, '$id_number', '$barcode', '$days_passed');");
           




            // return $days_passed;
    	     }

    }

    function dates_checking($connection){
    	//Format table
    	$erase=$connection->query("TRUNCATE TABLE  `due_books`");

    	//extract configurations
             $php_configurations=mysqli_query($connection,"SELECT * FROM `configurations`  WHERE id='1' ");
             $php_fetch_configuration=mysqli_fetch_array($php_configurations);
             $Allowed_days=$php_fetch_configuration['days'];
             $Allowed_fine=$php_fetch_configuration['fine'];

    	//check every student
             $php_datez=mysqli_query($connection,"SELECT * FROM due_dates WHERE days > $Allowed_days ");
             $numbers_of_rows=mysqli_num_rows($php_datez);

           //  for($x=0;$x < = $numbers_of_rows; $x++){//Loop to control number of times to excecute

             while	 ($fetch_names=mysqli_fetch_array($php_datez)){


             $id_number2=$fetch_names['id_number'];
             $barcode2=$fetch_names['barcode'];
             $due_days2=($fetch_names['days']-$Allowed_days);
             //Billing if it attracts a FINE
             $fine=$Allowed_fine * $due_days2;
              //INSERT INTO TABLE
             $update_table2=$connection->query("INSERT INTO `library`.`due_books` (`id`, `id_number`, `barcode`, `days`, `fine`) VALUES (NULL, '$id_number2', '$barcode2', '$due_days2', '$fine');");
         }//End loop
            
           
    }


     //updates_due_dates($cr7);
     // dates_checking($cr7);

	$id_number=mysqli_real_escape_string($cr7,$_POST['id_number']);
	$password=mysqli_real_escape_string($cr7,$_POST['password']);
  $activity=2;
  $monday=date('D');
  $session_id=rand(1,100000)."A".TIME()."L".date('d');
	//Check First
	function emp_access($c_id,$id,$pwd,$activity,$session_id){
    //Check activity   1=IN and 2=OUT
    if($activity=='1'){
      $sql_access=mysqli_query($c_id,"SELECT * FROM   `employees_access_tb` WHERE ec_number='$id'  AND ec_number NOT IN (SELECT ec_number FROM  `employee_in` ) ");
       $answer=mysqli_num_rows($sql_access);
       if($sql_access){
         if($answer > 0){
                  $exchange=$c_id->query("INSERT INTO `attendance`.`employee_in` (`id`, `ec_number`, `session_id`) VALUES (NULL, '$id','$session_id');");
         $exchange2=$c_id->query("DELETE FROM `attendance`.`employee_out` WHERE ec_number IN (SELECT ec_number FROM  `employee_in`) ;");
         // $exchange3=$c_id->query("DELETE FROM `attendance`.`employee_in` WHERE session_id NOT IN (SELECT session_id FROM  `attendance_in`) ;");
         }else{
          //Ignore

         }//end answer sql

          }//End sql true


    }else{//IF EMPIS OUT
       $sql_access=mysqli_query($c_id,"SELECT * FROM   `employees_access_tb` WHERE ec_number='$id'  AND ec_number NOT IN (SELECT ec_number FROM  `employee_out` ) ");
       $answer=mysqli_num_rows($sql_access);
        if($sql_access){
              if($answer > 0){
         $exchange=$c_id->query("INSERT INTO `attendance`.`employee_out` (`id`, `ec_number`) VALUES (NULL, '$id');");
        // $exchange2=$c_id->query("DELETE FROM `attendance`.`employee_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
         //Compute statistics
       }else{
        //Ignore

       }//end SQL answer
      }//end sql true




    }    
       return $answer;
	}
	function attendance($id,$activity,$session_id){ //SELECT * FROM lib_access_report WHERE status='Allowed' AND date_time=CURDATE()
  global $cr7;
    $computer_data=array(
      'remote_address'=>$_SERVER['REMOTE_ADDR']
      ,'http_agent'=>$_SERVER['HTTP_USER_AGENT']
      ,'remote_port'=>$_SERVER['REMOTE_PORT']
                                           );   echo "DONE-0"; 
    
    if($activity==1){
          echo "DONE ACTIVITY";
      $time_inn1=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
       $time_inn_copy=$cr7->query("INSERT INTO `attendance`.`attendance_in_copy` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
 
     $time_inn200=$cr7->query("INSERT INTO `attendance`.`attendance_out` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
          $activity_data='IN';
     // $time_inn=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
           }else{
          $activity_data='OUT';
          echo "DONE ACTIVITY 2";
    // $time_inn=$cr7->query("INSERT INTO `attendance`.`attendance_in` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
     $time_inn2=$cr7->query("INSERT INTO `attendance`.`attendance_out_copy` (`id`, `ec_number`, `session_id`, `time_in`, `date_in`) VALUES (NULL, '$id', '$session_id', NOW(), CURDATE() );");
     //NO MORE INSERTION BUT UPDATING
     $php_look_for_session=mysqli_query($cr7,"SELECT ec_number, session_id FROM `employee_in` WHERE ec_number='$id' ");
     $php_fetch_session=mysqli_fetch_array($php_look_for_session);
     $emp_number=$php_fetch_session['ec_number'];
     $emp_session=$php_fetch_session['session_id'];
//Updating===Crucial part
  $run_updates=$cr7->query("UPDATE `attendance`.`attendance_out` SET `time_in`=NOW(), `date_in`=CURDATE() WHERE `ec_number`='$emp_number' AND  `session_id`='$emp_session' ");
  echo "DONE ACTIVITY=next";


  //Compute hours
  $start_time=mysqli_query($cr7,"SELECT time_in,date_in FROM  `attendance_in` WHERE ec_number='$emp_number'  AND session_id='$emp_session' ");
  $fetch_time_start=mysqli_fetch_array($start_time);
  $emp_in=$fetch_time_start['time_in'];
   $emp_date_in=$fetch_time_start['date_in'];
   $first_parameter=$emp_date_in." ".$emp_in;

   //PARAMETER 2
 $start_time2=mysqli_query($cr7,"SELECT time_in,date_in FROM  `attendance_out` WHERE ec_number='$emp_number'  AND session_id='$emp_session' ");//and date
  $fetch_time_start2=mysqli_fetch_array($start_time2);
  $emp_in2=$fetch_time_start2['time_in'];
   $emp_date_in2=$fetch_time_start2['date_in'];
    $second_parameter=$emp_date_in2." ".$emp_in2;

//**********************************************************************Hour rate
    /* $sql258 = "SELECT * FROM salary_rates WHERE id=1 ";
                    $query = $cr7->query($sql258);
                    $row258 = $query258->fetch_assoc();
                    $current_rate=$row258['basic_rate'];

*/
 echo "DONE ACTIVITY=next rates<br>";


   //*********************
 $work_rate=mysqli_query($cr7,"SELECT * FROM salary_rates ");
    $rates109=mysqli_fetch_array($work_rate);
    $curr_rate=$rates109['basic_rate'];


   //*********************
             $hour_rate=$curr_rate * 0.25;
             // Declare two dates 
             $start_date = strtotime($first_parameter); 
             $end_date = strtotime($second_parameter); 
            // Get the difference and divide into  
            // total no. seconds 60/60/24 to get  
            // number of days 
           //echo "Difference between two dates: "
             $days_passed1=round(($end_date - $start_date)/60/60,2);//IF I WERE TO UDJUST 
              $days_passed= $days_passed1 * 0.5;
             $salary=$hour_rate*$days_passed;
   //*********************
       //insert into statistics
      $hour_statistics=$cr7->query("INSERT INTO `attendance`.`current_hours_statistics` (`id`, `ec_number`, `hours`, `hour_rate`, `payoff`, `month`, `date_generated`) VALUES (NULL, '$emp_number', '$days_passed', '$hour_rate', '$salary', '".date('M')."', CURDATE())");

$dashboard=$cr7->query("INSERT INTO `attendance`.`register_sheet` (`id`, `ec_number`, `time_in`, `time_off`, `status`, `date`) VALUES (NULL, '$emp_number', '$emp_in', '$emp_in2', 'present', '$emp_date_in2');");


      $exchange2=$cr7->query("DELETE FROM `attendance`.`employee_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
      //hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee

       $exchange2000=$cr7->query("DELETE FROM `attendance`.`attendance_in` WHERE ec_number IN (SELECT ec_number FROM  `employee_out`) ;");
      echo "DONE ACTIVITY=next rates TILL DELETE<br>";
     
          }
    $data=$computer_data['remote_address'].$computer_data['http_agent'].$computer_data['http_port'].date('Y:M:d');
		$sql_att=$cr7->query("INSERT INTO `attendance`.`attendance_tb` (`id`, `ec_number`,`session_id`, `time_in`, `time_out`, `month`, `status`, `branch`, `valid`, `computer_data`) VALUES (NULL, '$id','$session_id', NOW(), '', '".date('M')."', '$activity_data', 'Mutare', 'yes', '".$data."'); ");
		//return mysqli_num_rows($lib_limit);
    echo "DONE LAST LINE";
	}//END FUNCTION




                        function check_leave($ec){
                          global $cr7;
                          //Select start time
                          $start_time=mysqli_query($cr7,"SELECT ec_number FROM  `leave_tb` WHERE ec_number='$ec'  ");
                          return mysqli_num_rows($start_time);
                          }

	$lib_capacity=40;
           if(check_leave($id_number) < 1){//Leave
	if(emp_access($cr7,$id_number,$password,$activity,$session_id) > 0 ){
      
		//
          //echo "Mr Homwe";
          attendance($id_number,$activity,$session_id);
          //Compute statistics
          //insert record
         if($activity==1){
           echo "ACTIVITY 1"; 
                  $_SESSION['approved_project']="<br>
                          <div class='alert alert-success'>
                          <strong><center><h2>Success ".$id_number."  LOGGED IN </h2><i>Facial ID Detected</i></center></strong> 
                          </div>";
                    }else{
                       echo "activity 2"; 
                             $_SESSION['approved_project']="<br>
                             <div class='alert alert-info'>
                             <strong><center>Logged Out</center></strong> 
                             </div>";

                 }
    


	}else{  echo "PASSWORD WRONG OR DUPLICATE CHECKING IN"; 
                //insert record
     $_SESSION['approved_project']="<br>
              <div class='alert alert-danger'>
              <strong><center><h2>INCORRECT PASSWORD OR DUPLICATE CHECKING IN ".$id_number."</h2></center></strong> 
              </div>";


    }
		//Denied
		
	
}else{   $_SESSION['approved_project']="<br>
              <div class='alert alert-warning'>
              <strong><center><h2>EMPLOYEE ON LEAVE ".$id_number."</h2></center></strong> 
              </div>";


 //$exchange6=$c_r7->query("DELETE FROM `attendance`.`employee_in` WHERE session_id NOT IN (SELECT session_id FROM  `attendance_in`) ;");
     }//function emp access
                       

}else{
	//button not set
  echo "Homwenhgfd";

}


$activity4='Manually Logging Emplyee';
      $comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************

header('location:attendance_dashboard#');
                      
 unset($id_number,$password);




?>
