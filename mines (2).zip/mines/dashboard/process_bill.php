<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$claim_id=mysqli_real_escape_string($cn,$_POST['claim_id']);
$amount=mysqli_real_escape_string($cn,$_POST['amount']);
$service=mysqli_real_escape_string($cn,$_POST['service']);
$narration=mysqli_real_escape_string($cn,$_POST['narration']);
$bill_to=mysqli_real_escape_string($cn,$_POST['bill_to']);

$sl_data=mysqli_query($cn,"SELECT * FROM users WHERE 1 ");



if(1==1){
      if($bill_to=='Individual'){
      	$insert_data=mysqli_query($cn,"INSERT INTO `payments` (`id`, `client_id`, `holder`, `amount`, `amount_minus`,`date_created`,`narration`) VALUES (NULL, '$claim_id', '$claim_id', '0','$amount', CURDATE() ,'$narration'); ");

      }else if($bill_to=='All'){
      	//loop through
      	while($rows=mysqli_fetch_array($sl_data)){
      		$claim_id=$rows['client_id'];
      			$insert_data=mysqli_query($cn,"INSERT INTO `payments` (`id`, `client_id`, `holder`, `amount`, `amount_minus`,`date_created`,`narration`) VALUES (NULL, '$claim_id', '$claim_id', '0','$amount', CURDATE() ,'$narration'); ");
            
      	}


      }
	


if($insert_data){
	$_SESSION['approved_project']="True";
/*
	echo "Success".$id;
	echo "<br>";
	echo $claim_holder;
	echo "<br>";
	echo $claim_id;
	echo "<br>";
	echo $longitude;
	echo "<br>";
	echo $name_of_reef."--<br>".$_SESSION['approved_project'];
	*/
	

}else{
	$_SESSION['approved_project']="Failed";
	echo "Failed";
}


}
			
?>
<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "billing";
            }            
            document.write("<h1><center>Redirect.</center></h1>");
            setTimeout('Redirect()', 10);
         //-->
      </script>