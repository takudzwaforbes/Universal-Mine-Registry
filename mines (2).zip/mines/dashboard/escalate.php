<?php
 $con=mysqli_connect("localhost","root","","final");
 $query=mysqli_query($con,"SELECT * FROM faults WHERE status='Pending'");	
  //$url=$_SERVER['REQUEST_URI'];
  //header("Refresh: 10; URL=$url");	
  //this code refreshes a page every 10 seconds.	
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Escalate Fault</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body id="page-top" style="font-family:Arial, Helvetica, sans-serif">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="reports.php" style="font-family:Arial, Helvetica, sans-serif; font-style:italic">PowerTel Communications (Pvt) Ltd<img src="/final/Login_pages/assets/img/logo.png" height="45px" width="100px" style="margin-left:4px"></a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#" style="background-color:#00CC33">
      <i class="fas fa-bars"></i>    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group" style="margin-right:300px">
        <input type="text" class="form-control" placeholder="Search Using Fault Number.." aria-label="Search" aria-describedby="basic-addon2" style="width:350px">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button" style="background-color:#00CC33; border:none">
            <i class="fas fa-search"></i>          </button>
        </div>
      </div>
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0" style="background-color:">
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-bell fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">9+</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow mx-1">
        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-envelope fa-fw" style="color:#FFFFFF"></i>
          <span class="badge badge-danger">7</span>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>        </div>
      </li>
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-fw"></i>        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/final/Login_pages/login.php">Logout</a>        </div>
      </li>
    </ul>
  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav" style="background-color:#006699">
      <li class="nav-item">
        <a class="nav-link" href="reports.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>        </a>      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <h6 class="dropdown-header">Menu:</h6>
		  <a class="dropdown-item" href="/final/dashboard/reports.php">View Reports</a>
          <a class="dropdown-item" href="/final/dashboard/add_fault.php">Add New Fault</a>
          <a class="dropdown-item" href="/final/dashboard/escalate.php">Escalate Fault</a>
          <a class="dropdown-item" href="/final/dashboard/tables.php">View Pending Faults</a>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <a class="dropdown-item" href="#">Forgot Password?</a>
          <a class="dropdown-item" href="#">List of All technicians</a>        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>      </li>
      <li class="nav-item active">
        <a class="nav-link" href="tables.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>      </li>
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
		<form method="post" action="/final/dashboard/escalate.php">
<?php
	$conn=mysqli_connect("localhost","root","","final");
	if(isset($_POST["enter"]))
	{
		$company=mysqli_real_escape_string($conn,$_POST["company"]);
		$faultnumber=mysqli_real_escape_string($conn,$_POST["faultnumber"]);
		$notes=mysqli_real_escape_string($con,$_POST["notes"]);
		$confirm=mysqli_query($conn,"SELECT * FROM faults WHERE fault_number='$faultnumber' AND company_name='$company'");
		$count=mysqli_num_rows($confirm);
		if($count!=1)
		{
			echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> Specified Fault Not Found!
				</div>";
		}
		else
		{
			$fetch=mysqli_fetch_array($confirm);
			$switch=$fetch['switch'];
			$port=$fetch['port'];
			$manager=$fetch['account_manager'];
			$down_date=$fetch['date'];
			$date_now=date("Y-m-d H:i:s");
			$company=mysqli_real_escape_string($conn,$_POST["company"]);
			$faultnumber=mysqli_real_escape_string($conn,$_POST["faultnumber"]);
			$notes=mysqli_real_escape_string($conn,$_POST["notes"]);
			$update="INSERT INTO escalated_faults (company_name,fault_number,switch,port,account_manager,notes,date,escalation_date) VALUES ('$company','$faultnumber','$switch','$port','$manager','$notes','$down_date','$date_now')";
			if(!mysqli_query($conn,$update))
			{
			echo"<div class='alert alert-danger'>
  				<strong>Error!</strong> System Error occured please retry.!
				</div>";	
			}
			else
			{
			echo"<div class='alert alert-success'>
  				<strong>Success!</strong> Fault successfully escalated.
				</div>";
			}
		}
	}
?>
		<table align="center" style="text-align:center">
		<tr>
		 <td>
			<input type="text" class="form-control" name="company" id="company"value="<?php echo isset($_POST["company"])?$_POST["company"]:""; ?>" placeholder="Company Name" style="margin-bottom:3px; width:300px" required></td>
		</tr>
		<tr>
		<td><input type="text" class="form-control" name="faultnumber" id="faultnumber"value="<?php echo isset($_POST["faultnumber"])?$_POST["faultnumber"]:""; ?>" placeholder="Fault Number" style="margin-bottom:3px" required></td>
		</tr>
		<tr>
		<td>
		<textarea class="form-control" rows="3" id="notes" name="notes" placeholder="Escalation Notes"style="margin-bottom:3px; width:300px" required></textarea>					
		</td>
		</tr>
	<tr>
		<td><button type="submit" class="btn btn-primary" name="enter" id="enter" style="margin:1.5px; background-color:#0099FF; float:right">Enter</button></td>
	</tr>
		</table>
		</form>
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header" style="font-family:"Courier New", Courier, monospace">
            <i class="fas fa-table"></i>
            List of All Pending Faults</div>
          <div class="card-body">
            <div class="table-responsive">
			
			<form method="post" action="/final/dashboard/escalate.php">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Company</th>
                    <th>Physical</th>
                    <th>Contact Number</th>
                    <th>Date & Time</th>
                    <th>Fault Number</th>
                    <th>Account Manager</th>
					<th>Status</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>

                  </tr>
                </tfoot>
                <tbody>
               <?php
				while($results=mysqli_fetch_assoc($query))
				{
			echo"<tr>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['company_name']."</td>";
		echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['physical_address']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['contact_number']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['date']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['fault_number']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px'>".$results['account_manager']."</td>";
			echo"<td style='padding-right:8px; text-align:center;border-bottom:0.5px solid #000000; padding:5px; text-decoration:uderline'>".$results['status']."</td>";
					echo"</tr>";
				}
			
			?>
                </tbody>
              </table>
			  </form>
            </div>
          </div>
          <div class="card-footer small text-muted"><!--Updated yesterday at 11:59 PM--></div>
        </div>

        <p class="small text-center text-muted my-5">
          <em><!--More table examples coming soon...--></em>        </p>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright � System Developed by Simbarashe Nchenamilo</span>          </div>
        </div>
      </footer>
    </div>
    <!-- /.content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">�</span>          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>
</body>
</html>
