<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

 //Trim emil to remove white spaces
$a=array('firstname'=>mysqli_real_escape_string($cr7,$_POST['firstname']),
         'lastname'=>mysqli_real_escape_string($cr7,$_POST['lastname']),
         'email'=>mysqli_real_escape_string($cr7,$_POST['email']),
         'role'=>mysqli_real_escape_string($cr7,$_POST['role']),
     );
        $current_date=date('Y:m:d');
        $start_date = strtotime($current_date); 
        $end_date = strtotime($a['end_date']); 
        $abc=($end_date-$start_date/60/60/24);

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$create_ec=mysqli_query($cn,"SELECT max() FROM project_status WHERE  project__number='$new_email' ");
    $ecc = mysqli_num_rows($checkID);
    
    if(1==1){
      $ec_number=date('Y').rand(10,10000);
       $pin=rand(0,3000);

       $computer_data=array(
      'remote_address'=>$_SERVER['REMOTE_ADDR']
      ,'http_agent'=>$_SERVER['HTTP_USER_AGENT']
      ,'remote_port'=>$_SERVER['REMOTE_PORT']
                                          );
        $data=$computer_data['remote_address'].$computer_data['http_agent'].$computer_data['http_port'].date('Y:M:d')."J".$pin."S".$ec_number;

       
       $username=$_POST['firstname'].$_POST['lastname'];
    	 $add_project=$cr7->query("INSERT INTO `attendance`.`users` (`id`, `ec_number`, `firstname`, `lastname`, `username`, `password`, `email`, `role`, `date_enrolled`, `computer_data`) VALUES (NULL, '$ec_number', '".$_POST['firstname']."', '".$_POST['lastname']."', '$username', '".$pin."', '".$a['email']."', '".$a['role']."', CURDATE(), '$data'); ") or mysqli_error();
       $access_pin=$cr7->query("INSERT INTO `attendance`.`employees_access_tb` (`id`, `ec_number`, `password`) VALUES (NULL, '$ec_number', '$pin');");
     
     // echo "Project exist";
      //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center><h2>User Added Username is  ".$username."  "."Access PIN is ".$pin."<br>
  EC NUMBER IS  ".$ec_number."</h2>

  </center></strong> 
</div>";

    }else{
    	//insert record
     $_SESSION['approved_project']="<br>
              <div class='alert alert-info'>
              <strong><center>Failed</center></strong> 
              </div>";

 	   
        }
    
    echo $_POST['lastname']." ".$_POST['firstname'];
header('location:a_users#');


?>