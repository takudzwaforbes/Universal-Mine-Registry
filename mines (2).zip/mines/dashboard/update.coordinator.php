<?php
<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//Get Email
$projectid=$_GET['id'];
 //Trim emil to remove white spaces
 $new_projectid=trim($projectid);

//To be continued








?>