<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$claim_id=mysqli_real_escape_string($cn,$_POST['claim_id']);
$quantity=mysqli_real_escape_string($cn,$_POST['quantity']);
$revenue=mysqli_real_escape_string($cn,$_POST['revenue']);
$expense=mysqli_real_escape_string($cn,$_POST['expense']);
$date_created=mysqli_real_escape_string($cn,$_POST['date_created']);

$sl_data=mysqli_query($cn,"SELECT * FROM users WHERE 1 ");

$profit_loss=$revenue-$expense;

     
      	$insert_data=mysqli_query($cn,"INSERT INTO `output` (`id`, `client_id`, `narration`, `revenue`, `expense`, `date_created`, `transaction_date`, `profit_loss`) VALUES (NULL, '$claim_id', 'ABC', '$revenue', '$expense', CURDATE() , '$date_created','$profit_loss'); ");

     


      	


if($insert_data){
	$_SESSION['approved_project']="True";
/*
	echo "Success".$id;
	echo "<br>";
	echo $claim_holder;
	echo "<br>";
	echo $claim_id;
	echo "<br>";
	echo $longitude;
	echo "<br>";
	echo $name_of_reef."--<br>".$_SESSION['approved_project'];
	*/
	

}else{
	$_SESSION['approved_project']="Failed";
	echo "Failed";
}



			
?>
<script type = "text/javascript">
         <!--
            function Redirect() {
               window.location = "output";
            }            
            document.write("<h1><center>Redirect.</center></h1>");
            setTimeout('Redirect()', 10);
         //-->
      </script>