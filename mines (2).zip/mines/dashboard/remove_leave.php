<?php

//echo "Jeremiah";
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//details
$ec=$_GET['ec'];

/*function check_id($id){
	global $cr7;
	$check=mysqli_query($cr7,"SELECT id_number FROM access_entry WHERE id_number='$id' ");
	return mysqli_num_rows($check);
}
function book_existance($barcode){
	global $cr7;
	$books=mysqli_query($cr7,"SELECT barcode FROM books WHERE barcode='$barcode' ");
	return mysqli_num_rows($books);
}
function return_service($barcode){
	global $cr7;
	$service=mysqli_query($cr7,"SELECT status FROM books WHERE barcode='$barcode' ");
	$fetch=mysqli_fetch_assoc($service);
	return $fetch['status'];
}
function book_limit($id_number){
	global $cr7;
	$limit=mysqli_query($cr7,"SELECT id_number FROM issue_return  WHERE id_number='$id_number' ");
	return mysqli_num_rows($limit);
}*/



if(0== 0){
	//Procced
	if(1==1){
          //Procced book exist
		if(2==2){//AND return_service($barcode)=='Available'
		   if(80==80){
			//Insert
			$activity4='Removing user on Leave->'.$ec;
			$comp_data=shell_exec('getmac');

 $insert_service4=$cr7->query("INSERT INTO `attendance`.`log` (`id`, `ip`, `activity`, `user`, `transaction_date`, `computer_data`) VALUES (NULL, '".$_SERVER['REMOTE_ADDR']."', '$activity4', '".$_SESSION['identifier']."', NOW() ,'$comp_data');");

          //*********************
   /* $work_rate=mysqli_query($cr7,"SELECT * FROM salary_rates ");
    $rates109=mysqli_fetch_array($work_rate);
    $curr_rate=$rates109['basic_rate'];
             $payoff=$curr_rate * $hours;

*/
             //Update table
       $update=$cr7->query("DELETE FROM `leave_tb`  WHERE ec_number='$ec' ");
               //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Record Cleared</center></strong> 
</div>";

		    }else{
			//echo "Reached Book limit Return one or All";
			$_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Error Try Again</center></strong> 
</div>";
		     }//3==3


		}else
		{//$service_type=='Return' AND return_service($barcode)=='Borrowed'
		

		}//2==2

	}else{
		//Book not available in system
		echo "1==1";
	}//1==1

}else{
	//cannot procced not a student
	echo "0=0";
}//0==0


header('location:leave_days#');


?>