<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

//Get Email
$email=$_GET['projectid'];
 //Trim emil to remove white spaces
 $new_email=trim($email);

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$checkID=mysqli_query($cn,"SELECT * FROM project_status WHERE  project__number='$new_email' ");
    $count = mysqli_num_rows($checkID);
    
    if($count > 0){
    	 $add_project=$cn->query("UPDATE project_status SET status='Approved' WHERE project__number='$new_email' ");
     
    	echo "Project exist";
    	//create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-info'>
  <strong><center>Project Status Updated (Approved)</center></strong> 
</div>";

    }else{
    	//insert record
     $add_project=$cn->query("INSERT INTO project_status (project_id,project__number,status,datee) VALUES (NULL,'$new_email','Approved',NOW()) ");
       if($add_project==true){
 	    //success sms then search from coordinator relation--please search for coordinator with least projects
        $allocate=mysqli_query($cn,"SELECT email FROM coordinator_duties ORDER BY number_  ASC ");
        $fetch_email=mysqli_fetch_assoc($allocate);//since no loop it means it will take the first row found
        $row_email=$fetch_email['email'];
      //SELECT * FROM `coordinators` AS co JOIN hub_applicants AS ap ON co.project__number=ap.project_id
      //SELECT * FROM `coordinators` AS co JOIN hub_applicants AS ap ON co.project__number=ap.project_id JOIN coordinator_duties AS cod ON co.coordinator=cod.email
      
    //assign coordinator
        $assign=$cn->query("INSERT INTO coordinators (id,project__number,coordinator) VALUES (NULL,'$new_email','$row_email') ");

      //update that coordinator
        $select_duty=mysqli_query($cn,"SELECT COUNT(*) FROM coordinators WHERE coordinator='$row_email'  ");
        $fetch_number=mysqli_fetch_array($select_duty);
        $new_number_=$fetch_number[0];

          //update
        $update_record=mysqli_query($cn,"UPDATE  coordinator_duties SET number_='$new_number_' WHERE email='$row_email'  ");


 	    //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-success'>
  <strong><center>Success Project approved</center></strong> 
</div>";;

   echo "Success";
        }else{
         //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-danger'>
  <strong><center>Project Approval Failed</center></strong> 
</div>";;

        }
    }
    
header('location:reports');


?>