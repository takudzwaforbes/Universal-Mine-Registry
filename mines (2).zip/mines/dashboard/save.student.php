<?php
session_start();
//include ('../function.php');
include 'db/db.php';
error_reporting();

 //Trim emil to remove white spaces
$a=array('student_id'=>mysqli_real_escape_string($cr7,$_POST['student_id']),
      'firstname'=>mysqli_real_escape_string($cr7,$_POST['firstname']),
       'lastname'=>mysqli_real_escape_string($cr7,$_POST['lastname']),
       'status'=>mysqli_real_escape_string($cr7,$_POST['status']),
     );

function get_projectid($email){
	global $cn;
    $getID=$cn->query("SELECT id FROM submitted_papers WHERE email='$email' ");
    $row = $getID->fetch_assoc();
    return $row['id'];
}

	
	$checkID=mysqli_query($cn,"SELECT * FROM project_status WHERE  project__number='$new_email' ");
    $count = mysqli_num_rows($checkID);
    
    if(1==1){
      $random_pin=rand(1000,9999);

    	 $add_project=$cr7->query(" INSERT INTO `library`.`students` (`id`, `id_number`, `firstname`, `lastname`, `status`, `date_joined`) VALUES (NULL, '".strtoupper($a['student_id'])."', '".strtoupper($a['firstname'])."', '".strtoupper($a['lastname'])."', '".$a['status']."', NOW()) ") or mysqli_error();
       //Record 2
       $table2=$cr7->query("INSERT INTO `library`.`access_entry` (`id`, `id_number`, `password`, `status`) VALUES (NULL, '".$a['student_id']."', '$random_pin', '".$a['status']."');");
       //Validate
       $validate_table=$cr7->query("DELETE FROM `library`.`students` WHERE id_number='';  ");
       $Validate2=$cr7->query("DELETE FROM `library`.`access_entry` WHERE id_number NOT IN (SELECT id_number FROM `library`.`students` ) ");
     
      echo "Project exist";
      //create session success
    $_SESSION['approved_project']="<br>
<div class='alert alert-info'>
  <strong><center>Student Saved, PIN IS ".$random_pin."</center></strong> 
</div>";

    }else{
    	//insert record
     $_SESSION['approved_project']="<br>
              <div class='alert alert-info'>
              <strong><center>Student Already Exist</center></strong> 
              </div>";

 	   
        }
    
    
header('location:lib_students#');


?>